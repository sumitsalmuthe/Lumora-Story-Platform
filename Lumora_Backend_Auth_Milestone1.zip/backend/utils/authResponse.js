const toSafeUser = (user) => ({
  _id: user._id,
  username: user.username,
  email: user.email,
  avatar: user.avatar,
  bio: user.bio,
  role: user.role,
  roles: Array.isArray(user.roles) ? user.roles : [user.role || "reader"],
  verified: user.verified,
  isActive: user.isActive,
  writerProfile: user.writerProfile,
  createdAt: user.createdAt,
  updatedAt: user.updatedAt,
});

module.exports = { toSafeUser };
