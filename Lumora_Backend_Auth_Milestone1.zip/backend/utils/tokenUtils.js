const crypto = require("crypto");
const jwt = require("jsonwebtoken");

const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET || process.env.JWT_SECRET;
const ACCESS_EXPIRES_IN = process.env.JWT_ACCESS_EXPIRES_IN || process.env.JWT_EXPIRE || "15m";
const REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || "7d";

const parseDurationToMs = (value) => {
  if (typeof value === "number") return value;
  const match = String(value).trim().match(/^(\d+)\s*(s|m|h|d|w)$/i);
  if (!match) throw new Error(`Invalid duration: ${value}`);
  const amount = Number(match[1]);
  const unit = match[2].toLowerCase();
  const multipliers = { s: 1000, m: 60000, h: 3600000, d: 86400000, w: 604800000 };
  return amount * multipliers[unit];
};

const assertTokenConfig = () => {
  if (!ACCESS_SECRET) throw new Error("JWT access secret is not configured");
};

const createAccessToken = (user) => {
  assertTokenConfig();
  return jwt.sign(
    {
      sub: String(user._id),
      roles: Array.isArray(user.roles) ? user.roles : [user.role || "reader"],
    },
    ACCESS_SECRET,
    { expiresIn: ACCESS_EXPIRES_IN }
  );
};

const verifyAccessToken = (token) => {
  assertTokenConfig();
  return jwt.verify(token, ACCESS_SECRET);
};

const createRefreshToken = () => crypto.randomBytes(64).toString("base64url");
const hashRefreshToken = (token) => crypto.createHash("sha256").update(token).digest("hex");
const getRefreshExpiryDate = () => new Date(Date.now() + parseDurationToMs(REFRESH_EXPIRES_IN));

module.exports = {
  createAccessToken,
  verifyAccessToken,
  createRefreshToken,
  hashRefreshToken,
  getRefreshExpiryDate,
  parseDurationToMs,
};
