const User = require("../models/User");
const RefreshSession = require("../models/RefreshSession");
const {
  createAccessToken,
  createRefreshToken,
  hashRefreshToken,
  getRefreshExpiryDate,
} = require("../utils/tokenUtils");

const createSession = async ({ user, userAgent, ipAddress }) => {
  const refreshToken = createRefreshToken();
  await RefreshSession.create({
    user: user._id,
    tokenHash: hashRefreshToken(refreshToken),
    expiresAt: getRefreshExpiryDate(),
    userAgent: userAgent || "",
    ipAddress: ipAddress || "",
  });
  return { refreshToken, accessToken: createAccessToken(user) };
};

const revokeSession = async (refreshToken) => {
  if (!refreshToken) return;
  await RefreshSession.findOneAndUpdate(
    { tokenHash: hashRefreshToken(refreshToken), revokedAt: null },
    { $set: { revokedAt: new Date() } }
  );
};

const revokeAllSessions = async (userId) => {
  await RefreshSession.updateMany(
    { user: userId, revokedAt: null },
    { $set: { revokedAt: new Date() } }
  );
};

const rotateSession = async ({ refreshToken, userAgent, ipAddress }) => {
  if (!refreshToken) {
    const error = new Error("Refresh session required");
    error.statusCode = 401;
    throw error;
  }

  const tokenHash = hashRefreshToken(refreshToken);
  const session = await RefreshSession.findOne({ tokenHash }).select("+tokenHash +replacedByTokenHash").populate("user");

  if (!session) {
    const error = new Error("Invalid refresh session");
    error.statusCode = 401;
    throw error;
  }

  if (session.revokedAt) {
    // A previously rotated token was presented again. Revoke the account's
    // active sessions to limit the impact of refresh-token theft.
    await revokeAllSessions(session.user._id);
    const error = new Error("Refresh session has been revoked");
    error.statusCode = 401;
    throw error;
  }

  if (session.expiresAt <= new Date() || !session.user || !session.user.isActive) {
    await RefreshSession.findByIdAndUpdate(session._id, { $set: { revokedAt: new Date() } });
    const error = new Error("Refresh session expired");
    error.statusCode = 401;
    throw error;
  }

  const nextRefreshToken = createRefreshToken();
  const nextHash = hashRefreshToken(nextRefreshToken);
  session.revokedAt = new Date();
  session.replacedByTokenHash = nextHash;
  await session.save();

  await RefreshSession.create({
    user: session.user._id,
    tokenHash: nextHash,
    expiresAt: getRefreshExpiryDate(),
    userAgent: userAgent || session.userAgent,
    ipAddress: ipAddress || session.ipAddress,
  });

  return {
    refreshToken: nextRefreshToken,
    accessToken: createAccessToken(session.user),
    user: session.user,
  };
};

const register = async ({ username, email, password, userAgent, ipAddress }) => {
  const existing = await User.findOne({ $or: [{ email }, { username }] });
  if (existing) {
    const error = new Error(existing.email === email ? "Email already registered" : "Username already registered");
    error.statusCode = 409;
    throw error;
  }

  const user = await User.create({ username, email, password });
  return { user, ...(await createSession({ user, userAgent, ipAddress })) };
};

const login = async ({ email, password, userAgent, ipAddress }) => {
  const user = await User.findOne({ email });
  if (!user || !(await user.matchPassword(password))) {
    const error = new Error("Invalid email or password");
    error.statusCode = 401;
    throw error;
  }
  if (!user.isActive) {
    const error = new Error("Account disabled");
    error.statusCode = 403;
    throw error;
  }

  user.lastLogin = new Date();
  await user.save();
  return { user, ...(await createSession({ user, userAgent, ipAddress })) };
};

module.exports = { register, login, createSession, rotateSession, revokeSession, revokeAllSessions };
