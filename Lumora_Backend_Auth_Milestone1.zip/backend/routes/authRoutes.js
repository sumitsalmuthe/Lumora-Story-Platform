const express = require("express");
const {
  registerUser,
  loginUser,
  refresh,
  logout,
  logoutAll,
  getMe,
  changePassword,
  becomeWriter,
} = require("../controllers/auth/authController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/register", registerUser);
router.post("/login", loginUser);
router.post("/refresh", refresh);
router.post("/logout", logout);
router.post("/logout-all", protect, logoutAll);
router.get("/me", protect, getMe);
router.post("/change-password", protect, changePassword);
router.put("/become-writer", protect, becomeWriter);

module.exports = router;
