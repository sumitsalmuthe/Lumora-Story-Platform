const normalize = (value) => typeof value === "string" ? value.trim() : value;

const validateRegister = (body = {}) => {
  const username = normalize(body.username);
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : body.email;
  const password = body.password;
  const errors = [];

  if (!username) errors.push({ field: "username", message: "Username is required" });
  else if (username.length < 3 || username.length > 30) errors.push({ field: "username", message: "Username must be 3-30 characters" });
  if (!email) errors.push({ field: "email", message: "Email is required" });
  else if (!/^\S+@\S+\.\S+$/.test(email)) errors.push({ field: "email", message: "Invalid email address" });
  if (!password) errors.push({ field: "password", message: "Password is required" });
  else if (password.length < 8) errors.push({ field: "password", message: "Password must be at least 8 characters" });
  else if (password.length > 128) errors.push({ field: "password", message: "Password must not exceed 128 characters" });

  return { valid: errors.length === 0, errors, value: { username, email, password } };
};

const validateLogin = (body = {}) => {
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : body.email;
  const password = body.password;
  const errors = [];
  if (!email) errors.push({ field: "email", message: "Email is required" });
  if (!password) errors.push({ field: "password", message: "Password is required" });
  return { valid: errors.length === 0, errors, value: { email, password } };
};

const validateChangePassword = (body = {}) => {
  const currentPassword = body.currentPassword;
  const newPassword = body.newPassword;
  const errors = [];
  if (!currentPassword) errors.push({ field: "currentPassword", message: "Current password is required" });
  if (!newPassword) errors.push({ field: "newPassword", message: "New password is required" });
  else if (newPassword.length < 8 || newPassword.length > 128) errors.push({ field: "newPassword", message: "New password must be 8-128 characters" });
  else if (currentPassword === newPassword) errors.push({ field: "newPassword", message: "New password must differ from current password" });
  return { valid: errors.length === 0, errors, value: { currentPassword, newPassword } };
};

module.exports = { validateRegister, validateLogin, validateChangePassword };
