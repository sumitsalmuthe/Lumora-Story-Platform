const { verifyAccessToken } = require("../utils/tokenUtils");
const User = require("../models/User");

const protect = async (req, res, next) => {
  try {
    const header = req.headers.authorization || "";
    if (!header.startsWith("Bearer ")) return res.status(401).json({ success: false, message: "Authentication required", data: null });
    const token = header.slice(7).trim();
    const decoded = verifyAccessToken(token);
    const userId = decoded.sub || decoded.id;
    if (!userId) return res.status(401).json({ success: false, message: "Invalid access token", data: null });
    const user = await User.findById(userId).select("-password");
    if (!user) return res.status(401).json({ success: false, message: "User not found", data: null });
    if (!user.isActive) return res.status(403).json({ success: false, message: "Account is disabled", data: null });
    req.user = user;
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") return res.status(401).json({ success: false, message: "Access token expired", data: null });
    return res.status(401).json({ success: false, message: "Invalid access token", data: null });
  }
};

const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ success: false, message: "Authentication required", data: null });
  const userRoles = Array.isArray(req.user.roles) ? req.user.roles : [req.user.role];
  if (!roles.some((role) => userRoles.includes(role))) return res.status(403).json({ success: false, message: "You don't have permission for this action", data: null });
  next();
};

module.exports = { protect, authorize };
