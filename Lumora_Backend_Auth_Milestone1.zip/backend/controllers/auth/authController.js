const User = require("../../models/User");
const authService = require("../../services/authService");
const { toSafeUser } = require("../../utils/authResponse");
const { validateRegister, validateLogin, validateChangePassword } = require("../../validators/authValidator");

const REFRESH_COOKIE = "lumora_refresh";
const isProduction = process.env.NODE_ENV === "production";
const refreshCookieOptions = () => ({
  httpOnly: true,
  secure: isProduction,
  sameSite: process.env.COOKIE_SAMESITE || "lax",
  path: "/api/v1/auth",
  maxAge: 7 * 24 * 60 * 60 * 1000,
});

const setRefreshCookie = (res, token) => res.cookie(REFRESH_COOKIE, token, refreshCookieOptions());
const clearRefreshCookie = (res) => res.clearCookie(REFRESH_COOKIE, { ...refreshCookieOptions(), maxAge: undefined });
const requestMeta = (req) => ({ userAgent: req.get("user-agent"), ipAddress: req.ip });

const sendValidationError = (res, errors) => res.status(400).json({ success: false, message: "Validation failed", errors, data: null });

const registerUser = async (req, res, next) => {
  try {
    const result = validateRegister(req.body);
    if (!result.valid) return sendValidationError(res, result.errors);
    const session = await authService.register({ ...result.value, ...requestMeta(req) });
    setRefreshCookie(res, session.refreshToken);
    return res.status(201).json({ success: true, message: "Account created successfully", data: { user: toSafeUser(session.user), accessToken: session.accessToken } });
  } catch (error) { next(error); }
};

const loginUser = async (req, res, next) => {
  try {
    const result = validateLogin(req.body);
    if (!result.valid) return sendValidationError(res, result.errors);
    const session = await authService.login({ ...result.value, ...requestMeta(req) });
    setRefreshCookie(res, session.refreshToken);
    return res.status(200).json({ success: true, message: "Login successful", data: { user: toSafeUser(session.user), accessToken: session.accessToken } });
  } catch (error) { next(error); }
};

const refresh = async (req, res, next) => {
  try {
    const session = await authService.rotateSession({ refreshToken: req.cookies[REFRESH_COOKIE], ...requestMeta(req) });
    setRefreshCookie(res, session.refreshToken);
    return res.status(200).json({ success: true, message: "Session refreshed", data: { user: toSafeUser(session.user), accessToken: session.accessToken } });
  } catch (error) { clearRefreshCookie(res); next(error); }
};

const logout = async (req, res, next) => {
  try {
    await authService.revokeSession(req.cookies[REFRESH_COOKIE]);
    clearRefreshCookie(res);
    return res.status(200).json({ success: true, message: "Logged out successfully", data: null });
  } catch (error) { next(error); }
};

const logoutAll = async (req, res, next) => {
  try {
    await authService.revokeAllSessions(req.user._id);
    clearRefreshCookie(res);
    return res.status(200).json({ success: true, message: "All sessions revoked", data: null });
  } catch (error) { next(error); }
};

const getMe = async (req, res) => res.status(200).json({ success: true, message: "Authenticated user", data: { user: toSafeUser(req.user) } });

const changePassword = async (req, res, next) => {
  try {
    const result = validateChangePassword(req.body);
    if (!result.valid) return sendValidationError(res, result.errors);
    const user = await User.findById(req.user._id);
    if (!user || !(await user.matchPassword(result.value.currentPassword))) return res.status(401).json({ success: false, message: "Current password is incorrect", data: null });
    user.password = result.value.newPassword;
    await user.save();
    await authService.revokeAllSessions(user._id);
    clearRefreshCookie(res);
    return res.status(200).json({ success: true, message: "Password changed successfully. Please sign in again.", data: null });
  } catch (error) { next(error); }
};

const becomeWriter = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ success: false, message: "User not found", data: null });
    if (user.role === "writer") return res.status(409).json({ success: false, message: "Already a writer", data: null });
    user.role = "writer";
    user.writerProfile = { penName: user.username, joinedAsWriter: new Date() };
    await user.save();
    await authService.revokeAllSessions(user._id);
    const session = await authService.createSession({ user, ...requestMeta(req) });
    setRefreshCookie(res, session.refreshToken);
    return res.status(200).json({ success: true, message: "You are now a writer", data: { user: toSafeUser(user), accessToken: session.accessToken } });
  } catch (error) { next(error); }
};

module.exports = { registerUser, loginUser, refresh, logout, logoutAll, getMe, changePassword, becomeWriter };
