import apiClient from "../api/apiClient";

const authService = {
  login: async (credentials) => {
    const response = await apiClient.post("/auth/login", credentials);
    return response.data;
  },

  register: async (account) => {
    const response = await apiClient.post("/auth/register", account);
    return response.data;
  },

  becomeWriter: async () => {
    const response = await apiClient.put("/auth/become-writer");
    return response.data;
  },
};

export default authService;
