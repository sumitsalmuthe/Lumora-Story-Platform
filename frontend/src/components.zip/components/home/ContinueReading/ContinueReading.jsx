import { Link } from "react-router-dom";
import { FaArrowRight, FaBookOpen } from "react-icons/fa6";

import SectionHeader from "../../common/SectionHeader/SectionHeader";

import "./ContinueReading.css";

const continueStories = [
  {
    id: "continue-1",
    title: "The Weight of Silence",
    author: "Aarav Mehta",
    chapter: "Chapter 12",
    progress: 68,
  },
  {
  id: "continue-2",
  title: "Under a Dead Sky",
  author: "Aarav Mehta",
  chapter: "Chapter 8",
  progress: 42,
},
{
  id: "continue-3",
  title: "Beyond the Stars",
  author: "Mira Sen",
  chapter: "Chapter 17",
  progress: 84,
},
];

function ContinueReading() {
  return (
    <section className="lumora-continue-reading">
      <div className="lumora-continue-reading__container">
        <SectionHeader
          title="Continue Reading"
          description="Pick up where you left off."
          viewAllPath="/history"
        />

        <div className="lumora-continue-reading__list">
          {continueStories.map((story) => (
            <article
              key={story.id}
              className="lumora-continue-reading__card"
            >
              <div className="lumora-continue-reading__cover">
                <FaBookOpen size={20} />
              </div>

              <div className="lumora-continue-reading__content">
                <h3>{story.title}</h3>

                <p className="lumora-continue-reading__author">
                  {story.author}
                </p>

                <p className="lumora-continue-reading__chapter">
                  {story.chapter}
                </p>

                <div className="lumora-continue-reading__progress">
                  <div
                    className="lumora-continue-reading__progress-bar"
                    style={{
                      width: `${story.progress}%`,
                    }}
                  />
                </div>

                <span className="lumora-continue-reading__percentage">
                  {story.progress}% completed
                </span>
              </div>

              <Link
                to={`/read/${story.id}`}
                className="lumora-continue-reading__action"
              >
                <span>Continue</span>
                <FaArrowRight size={11} />
              </Link>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export default ContinueReading;