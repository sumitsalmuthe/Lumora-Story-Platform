import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FaArrowRight, FaBookOpen } from "react-icons/fa6";

import "./LatestBanners.css";

/* =========================================================
   LATEST STORIES
========================================================= */

const latestStories = [
  {
    id: "latest-banner-1",
    title: "The City After Midnight",
    author: "Arjun Verma",
    category: "Mystery",
    description:
      "Every night at midnight, one street in the city disappears.",
    coverImage:
      "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "latest-banner-2",
    title: "A World Between Pages",
    author: "Ishita Roy",
    category: "Fantasy",
    description:
      "A forgotten book opens a doorway to a world that should not exist.",
    coverImage:
      "https://images.unsplash.com/photo-1511108690759-009324a90311?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "latest-banner-3",
    title: "Seven Minutes to Dawn",
    author: "Rahul Shah",
    category: "Thriller",
    description:
      "Seven minutes remain before everything changes forever.",
    coverImage:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "latest-banner-4",
    title: "The Girl Who Remembered Tomorrow",
    author: "Anaya Singh",
    category: "Sci-Fi",
    description:
      "She wakes up every morning remembering a future that has not happened yet.",
    coverImage:
      "https://images.unsplash.com/photo-1446776877081-d282a0f896e2?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "latest-banner-5",
    title: "Where Shadows Sleep",
    author: "Riya Kapoor",
    category: "Fantasy",
    description:
      "A forgotten kingdom hides a secret that should never be awakened.",
    coverImage:
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "latest-banner-6",
    title: "Letters Never Sent",
    author: "Kabir Rao",
    category: "Romance",
    description:
      "Some stories begin with words that were never meant to be read.",
    coverImage:
      "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=1000&q=85",
  },
];

/* =========================================================
   TRENDING STORIES
========================================================= */

const trendingStories = [
  {
    id: "trending-banner-1",
    title: "Under a Dead Sky",
    author: "Riya Kapoor",
    category: "Horror",
    description:
      "The world ended quietly. What came after did not.",
    coverImage:
      "https://images.unsplash.com/photo-1511497584788-876760111969?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "trending-banner-2",
    title: "The Last Kingdom",
    author: "Dev Malhotra",
    category: "Fantasy",
    description:
      "A fallen prince returns to a kingdom that no longer remembers his name.",
    coverImage:
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "trending-banner-3",
    title: "The Silent Room",
    author: "Anaya Singh",
    category: "Mystery",
   description:
  "Every house has a secret. This one has a room no one is allowed to enter.",
    coverImage:
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "trending-banner-4",
    title: "Beyond the Stars",
    author: "Kabir Rao",
    category: "Sci-Fi",
    description:
      "Humanity's first journey beyond the solar system changes everything.",
    coverImage:
      "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "trending-banner-5",
    title: "Where Shadows Sleep",
    author: "Riya Kapoor",
    category: "Fantasy",
    description:
      "A forgotten kingdom hides a secret that should never be awakened.",
    coverImage:
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1000&q=85",
  },
  {
    id: "trending-banner-6",
    title: "The Last Signal",
    author: "Rahul Shah",
    category: "Sci-Fi",
    description:
      "A mysterious signal reaches Earth from somewhere beyond the stars.",
    coverImage:
      "https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?auto=format&fit=crop&w=1000&q=85",
  },
];

/* =========================================================
   STORY BANNER
========================================================= */

function StoryBanner({ story, type }) {
  const label = type === "latest" ? "LATEST" : "TRENDING";

  return (
    <article
      className="lumora-latest-banner"
      style={{
        "--banner-image": `url("${story.coverImage}")`,
      }}
    >
      {/* Blurred background */}
      <div className="lumora-latest-banner__background" />

      {/* Dark overlay */}
      <div className="lumora-latest-banner__overlay" />

      {/* Content */}
      <div className="lumora-latest-banner__content">

        {/* Cover */}
        <div className="lumora-latest-banner__cover">
          <img
            src={story.coverImage}
            alt={story.title}
          />
        </div>

        {/* Story information */}
        <div className="lumora-latest-banner__info">

          <div className="lumora-latest-banner__top">

            <span className="lumora-latest-banner__category">
              {story.category}
            </span>

            <span className="lumora-latest-banner__label">
              {label}
            </span>

          </div>

          <h3>
            {story.title}
          </h3>

          <p className="lumora-latest-banner__author">
            by {story.author}
          </p>

          <p className="lumora-latest-banner__description">
            {story.description}
          </p>

         <Link
  to={`/stories/${story.id}`}
  className="lumora-latest-banner__button"
>
            <FaBookOpen size={11} />

            Read Story

            <FaArrowRight size={10} />
          </Link>

        </div>
      </div>

      {/* Progress */}
      <div className="lumora-latest-banner__progress">
        <span />
      </div>
    </article>
  );
}

/* =========================================================
   LATEST BANNERS
========================================================= */

function LatestBanners() {

  const [latestIndex, setLatestIndex] = useState(0);

  const [trendingIndex, setTrendingIndex] = useState(0);

  useEffect(() => {

    const interval = setInterval(() => {

      setLatestIndex((current) => {
        return (
          (current + 1) %
          latestStories.length
        );
      });

      setTrendingIndex((current) => {
        return (
          (current + 1) %
          trendingStories.length
        );
      });

    }, 4000);

    return () => {
      clearInterval(interval);
    };

  }, []);

  return (
    <section className="lumora-latest-banners">

      <div className="lumora-latest-banners__container">

        {/* =================================================
            HEADER
        ================================================= */}

        <div className="lumora-latest-banners__header">

          <div>

            <span className="lumora-latest-banners__eyebrow">
              FRESH ON LUMORA
            </span>

            <h2>
              Stories worth discovering.
            </h2>

            <p>
              Discover the newest stories and
              see what's capturing readers' attention.
            </p>

          </div>

          <Link
            to="/discover"
            className="lumora-latest-banners__view-all"
          >
            View all

            <FaArrowRight size={11} />
          </Link>

        </div>

        {/* =================================================
            TWO BANNERS
        ================================================= */}

        <div className="lumora-latest-banners__grid">

          {/* LEFT — LATEST */}

          <StoryBanner
            key={`latest-${latestIndex}`}
            story={latestStories[latestIndex]}
            type="latest"
          />

          {/* RIGHT — TRENDING */}

          <StoryBanner
            key={`trending-${trendingIndex}`}
            story={trendingStories[trendingIndex]}
            type="trending"
          />

        </div>

      </div>

    </section>
  );
}

export default LatestBanners;