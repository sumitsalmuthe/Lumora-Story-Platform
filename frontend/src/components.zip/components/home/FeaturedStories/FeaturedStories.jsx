import SectionHeader from "../../common/SectionHeader/SectionHeader";
import StoryRow from "../../story/StoryRow/StoryRow";

import "./FeaturedStories.css";

const featuredStories = [
  {
    id: "featured-1",
    title: "The Weight of Silence",
    author: {
      id: "writer-1",
      username: "Aarav Mehta",
    },
    category: "Fiction",
    storyType: "Fiction",
    shortDescription:
      "A story about secrets, choices, and the things we never say.",
    views: 12400,
    likes: 860,
    bookmarks: 320,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "featured-2",
    title: "Beyond the Stars",
    author: {
      id: "writer-2",
      username: "Mira Sen",
    },
    category: "Sci-Fi",
    storyType: "Fiction",
    shortDescription:
      "A journey beyond everything humanity thought it knew.",
    views: 10900,
    likes: 740,
    bookmarks: 290,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "featured-3",
    title: "Where Shadows Sleep",
    author: {
      id: "writer-3",
      username: "Riya Kapoor",
    },
    category: "Fantasy",
    storyType: "Fiction",
    shortDescription:
      "A forgotten kingdom hides a secret that should never be awakened.",
    views: 8700,
    likes: 620,
    bookmarks: 250,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "featured-4",
    title: "Letters Never Sent",
    author: {
      id: "writer-4",
      username: "Kabir Rao",
    },
    category: "Romance",
    storyType: "Fiction",
    shortDescription:
      "Some stories begin with words that were never meant to be read.",
    views: 7600,
    likes: 510,
    bookmarks: 210,
    status: "Published",
    mature: false,
    coverImage: "",
  },
];

function FeaturedStories() {
  return (
    <section className="lumora-featured-stories">
      <div className="lumora-featured-stories__container">
        <SectionHeader
          title="Featured Stories"
          description="Discover stories worth adding to your reading list."
          viewAllPath="/discover"
        />

        <StoryRow
          stories={featuredStories}
          columns={4}
          showDescription={false}
          showStats
          showBookmark
        />
      </div>
    </section>
  );
}

export default FeaturedStories;