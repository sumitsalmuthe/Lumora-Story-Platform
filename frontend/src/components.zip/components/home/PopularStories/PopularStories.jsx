import SectionHeader from "../../common/SectionHeader/SectionHeader";
import StoryRow from "../../story/StoryRow/StoryRow";

import "./PopularStories.css";

const popularStories = [
  {
    id: "popular-1",
    title: "The Last Kingdom",
    author: {
      id: "writer-5",
      username: "Dev Malhotra",
    },
    category: "Fantasy",
    storyType: "Fiction",
    shortDescription:
      "A fallen prince must return to a kingdom that no longer remembers him.",
    views: 245000,
    likes: 18200,
    bookmarks: 9400,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "popular-2",
    title: "Under a Dead Sky",
    author: {
      id: "writer-1",
      username: "Aarav Mehta",
    },
    category: "Horror",
    storyType: "Fiction",
    shortDescription:
      "The world ended quietly. What came after did not.",
    views: 198000,
    likes: 15400,
    bookmarks: 8200,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "popular-3",
    title: "The Silent Room",
    author: {
      id: "writer-6",
      username: "Naina Kapoor",
    },
    category: "Mystery",
    storyType: "Fiction",
    shortDescription:
      "Every house has a secret. This one has a room no one is allowed to enter.",
    views: 176000,
    likes: 12800,
    bookmarks: 7100,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "popular-4",
    title: "Beyond the Stars",
    author: {
      id: "writer-2",
      username: "Mira Sen",
    },
    category: "Sci-Fi",
    storyType: "Fiction",
    shortDescription:
      "Humanity's first journey beyond the solar system changes everything.",
    views: 154000,
    likes: 11600,
    bookmarks: 6300,
    status: "Published",
    mature: false,
    coverImage: "",
  },
];

function PopularStories() {
  return (
    <section className="lumora-popular-stories">
      <div className="lumora-popular-stories__container">
        <SectionHeader
          title="Popular Stories"
          description="Stories that readers keep coming back to."
          viewAllPath="/popular"
        />

        <StoryRow
          stories={popularStories}
          columns={4}
          showDescription={false}
          showStats
          showBookmark
        />
      </div>
    </section>
  );
}

export default PopularStories;