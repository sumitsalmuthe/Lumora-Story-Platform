import { Link } from "react-router-dom";
import { FaArrowRight, FaPenNib } from "react-icons/fa6";

import SectionHeader from "../../common/SectionHeader/SectionHeader";

import "./FeaturedWriters.css";

const featuredWriters = [
  {
    id: "writer-1",
    username: "Aarav Mehta",
    bio: "Writes stories about silence, survival and the choices between them.",
    stories: 12,
    followers: "18.4K",
    initials: "AM",
  },
  {
    id: "writer-2",
    username: "Mira Sen",
    bio: "Science fiction, strange worlds and stories about humanity.",
    stories: 8,
    followers: "12.7K",
    initials: "MS",
  },
  {
    id: "writer-3",
    username: "Riya Kapoor",
    bio: "Fantasy writer building worlds where nothing is quite what it seems.",
    stories: 16,
    followers: "10.2K",
    initials: "RK",
  },
  {
    id: "writer-4",
    username: "Kabir Rao",
    bio: "Romance and contemporary fiction with complicated characters.",
    stories: 9,
    followers: "8.9K",
    initials: "KR",
  },
];

function FeaturedWriters() {
  return (
    <section className="lumora-featured-writers">
      <div className="lumora-featured-writers__container">
        <SectionHeader
          title="Featured Writers"
          description="Meet some of the voices behind the stories."
          viewAllPath="/community"
        />

        <div className="lumora-featured-writers__grid">
          {featuredWriters.map((writer) => (
            <article
              key={writer.id}
              className="lumora-featured-writers__card"
            >
              <div className="lumora-featured-writers__avatar">
                {writer.initials}
              </div>

              <div className="lumora-featured-writers__content">
                <Link
                  to={`/profile/${writer.id}`}
                  className="lumora-featured-writers__name"
                >
                  {writer.username}
                </Link>

                <p className="lumora-featured-writers__bio">
                  {writer.bio}
                </p>

                <div className="lumora-featured-writers__stats">
                  <span>
                    <strong>{writer.stories}</strong>
                    Stories
                  </span>

                  <span>
                    <strong>{writer.followers}</strong>
                    Followers
                  </span>
                </div>
              </div>

              <Link
                to={`/profile/${writer.id}`}
                className="lumora-featured-writers__action"
              >
                <FaArrowRight size={11} />
              </Link>
            </article>
          ))}
        </div>

        <div className="lumora-featured-writers__bottom">
          <Link
            to="/become-writer"
            className="lumora-featured-writers__writer-link"
          >
            <FaPenNib size={12} />
            Start writing on Lumora
          </Link>
        </div>
      </div>
    </section>
  );
}

export default FeaturedWriters;