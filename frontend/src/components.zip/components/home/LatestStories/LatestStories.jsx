import SectionHeader from "../../common/SectionHeader/SectionHeader";
import StoryRow from "../../story/StoryRow/StoryRow";

import "./LatestStories.css";

const latestStories = [
  {
    id: "latest-1",
    title: "The City After Midnight",
    author: {
      id: "writer-7",
      username: "Arjun Verma",
    },
    category: "Mystery",
    storyType: "Fiction",
    shortDescription:
      "Every night at midnight, one street in the city disappears.",
    views: 3200,
    likes: 280,
    bookmarks: 140,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "latest-2",
    title: "A World Between Pages",
    author: {
      id: "writer-8",
      username: "Ishita Roy",
    },
    category: "Fantasy",
    storyType: "Fiction",
    shortDescription:
      "A forgotten book opens a doorway to a world that should not exist.",
    views: 2800,
    likes: 230,
    bookmarks: 118,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "latest-3",
    title: "Seven Minutes to Dawn",
    author: {
      id: "writer-9",
      username: "Rahul Shah",
    },
    category: "Thriller",
    storyType: "Fiction",
    shortDescription:
      "Seven minutes remain before everything changes forever.",
    views: 2100,
    likes: 190,
    bookmarks: 92,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "latest-4",
    title: "The Girl Who Remembered Tomorrow",
    author: {
      id: "writer-10",
      username: "Anaya Singh",
    },
    category: "Sci-Fi",
    storyType: "Fiction",
    shortDescription:
      "She wakes up every morning remembering a future that has not happened yet.",
    views: 1800,
    likes: 160,
    bookmarks: 76,
    status: "Published",
    mature: false,
    coverImage: "",
  },
];

function LatestStories() {
  return (
    <section className="lumora-latest-stories">
      <div className="lumora-latest-stories__container">
        <SectionHeader
          title="Latest Stories"
          description="Fresh stories and new voices to discover."
          viewAllPath="/discover"
        />

        <StoryRow
          stories={latestStories}
          columns={4}
          showDescription={false}
          showStats
          showBookmark
        />
      </div>
    </section>
  );
}

export default LatestStories;