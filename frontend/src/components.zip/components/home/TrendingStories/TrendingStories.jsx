import SectionHeader from "../../common/SectionHeader/SectionHeader";
import StoryRow from "../../story/StoryRow/StoryRow";

import "./TrendingStories.css";

const trendingStories = [
  {
    id: "trending-1",
    title: "Under a Dead Sky",
    author: {
      id: "writer-1",
      username: "Aarav Mehta",
    },
    category: "Horror",
    storyType: "Fiction",
    shortDescription:
      "When the world falls silent, survival becomes the only rule.",
    views: 92400,
    likes: 5840,
    bookmarks: 2310,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "trending-2",
    title: "The Last Signal",
    author: {
      id: "writer-2",
      username: "Mira Sen",
    },
    category: "Sci-Fi",
    storyType: "Fiction",
    shortDescription:
      "A mysterious signal reaches Earth from somewhere beyond the stars.",
    views: 78300,
    likes: 4620,
    bookmarks: 1980,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "trending-3",
    title: "Where Shadows Sleep",
    author: {
      id: "writer-3",
      username: "Riya Kapoor",
    },
    category: "Fantasy",
    storyType: "Fiction",
    shortDescription:
      "A forgotten kingdom hides a secret that should never be awakened.",
    views: 64100,
    likes: 3970,
    bookmarks: 1740,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "trending-4",
    title: "Letters Never Sent",
    author: {
      id: "writer-4",
      username: "Kabir Rao",
    },
    category: "Romance",
    storyType: "Fiction",
    shortDescription:
      "Some stories begin with words that were never meant to be read.",
    views: 52800,
    likes: 3510,
    bookmarks: 1420,
    status: "Published",
    mature: false,
    coverImage: "",
  },
];

function TrendingStories() {
  return (
    <section className="lumora-trending-stories">
      <div className="lumora-trending-stories__container">
        <SectionHeader
          title="Trending Now"
          description="Stories readers are discovering right now."
          viewAllPath="/popular"
        />

        <StoryRow
          stories={trendingStories}
          columns={4}
          showDescription={false}
          showStats
          showBookmark
        />
      </div>
    </section>
  );
}

export default TrendingStories;