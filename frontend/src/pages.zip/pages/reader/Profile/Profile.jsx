import { Link, useParams } from "react-router-dom";
import {
  FaArrowRight,
  FaBookOpen,
  FaCalendar,
  FaCheck,
  FaHeart,
  FaUserGroup,
} from "react-icons/fa6";

import "./Profile.css";

const writers = {
  "writer-1": {
    username: "Aarav Mehta",
    initials: "AM",
    bio: "Writes stories about silence, survival and the choices between them.",
    followers: "18.4K",
    following: "126",
    stories: 12,
    totalViews: "924K",
    joined: "August 2024",
    verified: true,
    storiesList: [
      {
        id: "under-a-dead-sky",
        title: "Under a Dead Sky",
        category: "Horror",
        description:
          "The world ended quietly. What came after did not.",
        views: "198K",
        likes: "15.4K",
        status: "Ongoing",
      },
      {
        id: "the-last-signal",
        title: "The Last Signal",
        category: "Sci-Fi",
        description:
          "A mysterious signal reaches Earth from somewhere beyond the stars.",
        views: "78K",
        likes: "4.6K",
        status: "Completed",
      },
      {
        id: "the-silent-road",
        title: "The Silent Road",
        category: "Thriller",
        description:
          "One road. No people. And a destination nobody remembers.",
        views: "42K",
        likes: "3.1K",
        status: "Completed",
      },
    ],
  },

  "writer-2": {
    username: "Mira Sen",
    initials: "MS",
    bio: "Science fiction, strange worlds and stories about humanity.",
    followers: "12.7K",
    following: "84",
    stories: 8,
    totalViews: "615K",
    joined: "January 2025",
    verified: true,
    storiesList: [
      {
        id: "the-last-signal",
        title: "The Last Signal",
        category: "Sci-Fi",
        description:
          "A mysterious signal reaches Earth from somewhere beyond the stars.",
        views: "78K",
        likes: "4.6K",
        status: "Completed",
      },
      {
        id: "beyond-the-stars",
        title: "Beyond the Stars",
        category: "Sci-Fi",
        description:
          "Humanity's first journey beyond the solar system changes everything.",
        views: "154K",
        likes: "11.6K",
        status: "Ongoing",
      },
    ],
  },

  "writer-3": {
    username: "Riya Kapoor",
    initials: "RK",
    bio: "Fantasy writer building worlds where nothing is quite what it seems.",
    followers: "10.2K",
    following: "92",
    stories: 16,
    totalViews: "530K",
    joined: "March 2024",
    verified: false,
    storiesList: [
      {
        id: "where-shadows-sleep",
        title: "Where Shadows Sleep",
        category: "Fantasy",
        description:
          "A forgotten kingdom hides a secret that should never be awakened.",
        views: "87K",
        likes: "7.2K",
        status: "Ongoing",
      },
      {
        id: "the-forgotten-crown",
        title: "The Forgotten Crown",
        category: "Fantasy",
        description:
          "A lost crown brings an ancient kingdom back to life.",
        views: "54K",
        likes: "4.8K",
        status: "Completed",
      },
    ],
  },
};

const defaultWriter = writers["writer-1"];

function Profile() {
  const { userId } = useParams();

  const writer = writers[userId] || defaultWriter;

  return (
    <main className="lumora-profile">
      {/* =====================================================
          PROFILE HERO
      ===================================================== */}

      <section className="lumora-profile__hero">
        <div className="lumora-profile__container">
          <div className="lumora-profile__hero-content">
            <div className="lumora-profile__avatar">
              {writer.initials}
            </div>

            <div className="lumora-profile__identity">
              <div className="lumora-profile__name-row">
                <h1>{writer.username}</h1>

                {writer.verified && (
                  <span
                    className="lumora-profile__verified"
                    title="Verified writer"
                  >
                    <FaCheck size={9} />
                  </span>
                )}
              </div>

              <p>{writer.bio}</p>

              <div className="lumora-profile__meta">
                <span>
                  <FaCalendar size={10} />
                  Joined {writer.joined}
                </span>

                <span>
                  <FaBookOpen size={10} />
                  {writer.stories} Stories
                </span>
              </div>
            </div>

            <button
              type="button"
              className="lumora-profile__follow-button"
            >
              <FaUserGroup size={12} />
              Follow
            </button>
          </div>

          {/* =================================================
              STATS
          ================================================= */}

          <div className="lumora-profile__stats">
            <div>
              <strong>{writer.followers}</strong>
              <span>Followers</span>
            </div>

            <div>
              <strong>{writer.following}</strong>
              <span>Following</span>
            </div>

            <div>
              <strong>{writer.stories}</strong>
              <span>Stories</span>
            </div>

            <div>
              <strong>{writer.totalViews}</strong>
              <span>Total views</span>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          STORIES
      ===================================================== */}

      <section className="lumora-profile__stories">
        <div className="lumora-profile__container">
          <div className="lumora-profile__section-header">
            <div>
              <span className="lumora-profile__eyebrow">
                WRITTEN BY {writer.username.toUpperCase()}
              </span>

              <h2>Stories</h2>
            </div>

            <span className="lumora-profile__story-count">
              {writer.stories} published
            </span>
          </div>

          <div className="lumora-profile__story-list">
            {writer.storiesList.map((story) => (
              <article
                key={story.id}
                className="lumora-profile__story-card"
              >
                <div className="lumora-profile__story-cover">
                  <FaBookOpen size={21} />

                  <span>{story.category}</span>
                </div>

                <div className="lumora-profile__story-content">
                  <div className="lumora-profile__story-title-row">
                    <Link
                      to={`/stories/${story.id}`}
                      className="lumora-profile__story-title"
                    >
                      {story.title}
                    </Link>

                    <span className="lumora-profile__story-status">
                      {story.status}
                    </span>
                  </div>

                  <p>{story.description}</p>

                  <div className="lumora-profile__story-stats">
                    <span>
                      <FaBookOpen size={10} />
                      {story.views} views
                    </span>

                    <span>
                      <FaHeart size={10} />
                      {story.likes} likes
                    </span>
                  </div>
                </div>

                <Link
                  to={`/stories/${story.id}`}
                  className="lumora-profile__story-action"
                  aria-label={`Open ${story.title}`}
                >
                  <FaArrowRight size={11} />
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================
          ABOUT WRITER
      ===================================================== */}

      <section className="lumora-profile__about">
        <div className="lumora-profile__container">
          <div className="lumora-profile__about-card">
            <div className="lumora-profile__about-icon">
              <FaBookOpen size={17} />
            </div>

            <div>
              <span className="lumora-profile__eyebrow">
                ABOUT THE WRITER
              </span>

              <h2>{writer.username}</h2>

              <p>{writer.bio}</p>

              <Link to="/community">
                Connect with the writer
                <FaArrowRight size={10} />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

export default Profile;
