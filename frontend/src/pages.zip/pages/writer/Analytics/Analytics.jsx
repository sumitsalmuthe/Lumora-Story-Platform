import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  BarChart3,
  BookOpen,
  Eye,
  Heart,
  MessageCircle,
  TrendingUp,
  ArrowUpRight,
  ChevronDown,
  Settings,
  Plus,
  PenLine,
  Check,
} from "lucide-react";

import lumoraLogo from "../../../assets/logo/lumora-logo-bold.svg";

import "./Analytics.css";

const analyticsData = {
  "Last 7 days": {
    views: "24.8K",
    likes: "1.82K",
    comments: "286",
    stories: "12",
    viewChange: "+8.4%",
    likeChange: "+6.2%",
    commentChange: "+4.8%",
    storyChange: "+1",
    totalViews: "24.8K",
    totalGrowth: "+8.4%",
    followers: "18.4K",
    followerGrowth: "+2.8% this week",
    months: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    chartValues: [18, 24, 21, 38, 44, 61, 78],
  },

  "Last 30 days": {
    views: "108K",
    likes: "8.2K",
    comments: "1.1K",
    stories: "12",
    viewChange: "+12.1%",
    likeChange: "+9.6%",
    commentChange: "+7.4%",
    storyChange: "+1",
    totalViews: "108K",
    totalGrowth: "+12.1%",
    followers: "18.4K",
    followerGrowth: "+6.7% this month",
    months: ["Week 1", "Week 2", "Week 3", "Week 4"],
    chartValues: [24, 38, 56, 82],
  },

  "Last 3 months": {
    views: "382K",
    likes: "28.7K",
    comments: "3.9K",
    stories: "12",
    viewChange: "+15.3%",
    likeChange: "+10.8%",
    commentChange: "+7.9%",
    storyChange: "+2",
    totalViews: "382K",
    totalGrowth: "+15.3%",
    followers: "18.4K",
    followerGrowth: "+10.4% this period",
    months: ["Jun", "Jul", "Aug"],
    chartValues: [18, 34, 52],
  },

  "Last 6 months": {
    views: "924K",
    likes: "68.4K",
    comments: "9.2K",
    stories: "12",
    viewChange: "+18.6%",
    likeChange: "+12.4%",
    commentChange: "+8.7%",
    storyChange: "+2",
    totalViews: "924K",
    totalGrowth: "+18.6%",
    followers: "18.4K",
    followerGrowth: "+14.2% this month",
    months: ["Mar", "Apr", "May", "Jun", "Jul", "Aug"],
    chartValues: [15, 22, 20, 45, 67, 82],
  },

  "Last 12 months": {
    views: "1.84M",
    likes: "136K",
    comments: "18.6K",
    stories: "12",
    viewChange: "+24.8%",
    likeChange: "+18.3%",
    commentChange: "+13.6%",
    storyChange: "+4",
    totalViews: "1.84M",
    totalGrowth: "+24.8%",
    followers: "18.4K",
    followerGrowth: "+22.1% this year",
    months: [
      "Sep",
      "Oct",
      "Nov",
      "Dec",
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
    ],
    chartValues: [12, 19, 27, 24, 35, 42, 48, 56, 62, 69, 75, 88],
  },
};

function Analytics() {
  const [timeRange, setTimeRange] = useState("Last 6 months");
  const [showTimeRange, setShowTimeRange] = useState(false);

  const dropdownRef = useRef(null);

  const timeRanges = Object.keys(analyticsData);

  const currentData = analyticsData[timeRange];

  /*
   * Close dropdown when clicking outside.
   */
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target)
      ) {
        setShowTimeRange(false);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, []);

  /*
   * Close dropdown with Escape.
   */
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setShowTimeRange(false);
      }
    };

    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  const stats = [
    {
      label: "Total Views",
      value: currentData.views,
      change: currentData.viewChange,
      icon: Eye,
    },
    {
      label: "Total Likes",
      value: currentData.likes,
      change: currentData.likeChange,
      icon: Heart,
    },
    {
      label: "Comments",
      value: currentData.comments,
      change: currentData.commentChange,
      icon: MessageCircle,
    },
    {
      label: "Stories",
      value: currentData.stories,
      change: currentData.storyChange,
      icon: BookOpen,
    },
  ];

  const stories = [
    {
      title: "The Last Kingdom",
      category: "Fantasy",
      views: "245K",
      likes: "18.2K",
      comments: "1.4K",
      growth: "+24.8%",
    },
    {
      title: "Under a Dead Sky",
      category: "Horror",
      views: "198K",
      likes: "15.4K",
      comments: "2.1K",
      growth: "+19.2%",
    },
    {
      title: "The Silent Room",
      category: "Mystery",
      views: "17.6K",
      likes: "1.3K",
      comments: "710",
      growth: "+11.5%",
    },
    {
      title: "Beyond the Stars",
      category: "Sci-Fi",
      views: "154K",
      likes: "11.6K",
      comments: "1.8K",
      growth: "+16.7%",
    },
  ];

  const getChartPath = () => {
    const values = currentData.chartValues;

    if (values.length === 1) {
      return `M 0 140 L 900 140`;
    }

    const max = Math.max(...values);
    const min = Math.min(...values);
    const range = max - min || 1;

    const points = values.map((value, index) => {
      const x = (index / (values.length - 1)) * 900;
      const y = 225 - ((value - min) / range) * 165;

      return { x, y };
    });

    let path = `M ${points[0].x} ${points[0].y}`;

    for (let i = 1; i < points.length; i += 1) {
      const previous = points[i - 1];
      const current = points[i];

      const controlX = (previous.x + current.x) / 2;

      path += `
        C ${controlX} ${previous.y},
          ${controlX} ${current.y},
          ${current.x} ${current.y}
      `;
    }

    return path;
  };

  const chartPath = getChartPath();

  const chartFillPath = `
    ${chartPath}
    L 900 280
    L 0 280
    Z
  `;

  return (
    <div className="analytics-page">
      {/* =========================================
          SIDEBAR
      ========================================= */}

      <aside className="writer-sidebar">
        <Link to="/writer/dashboard" className="writer-brand">
  <img
    src={lumoraLogo}
    alt="Lumora"
    className="writer-brand-logo"
  />
</Link>

        <nav className="writer-nav">
          <Link to="/writer/dashboard">
            <BarChart3 size={18} />
            <span>Dashboard</span>
          </Link>

          <Link to="/my-stories">
            <BookOpen size={18} />
            <span>My Stories</span>
          </Link>

          <Link to="/create-story">
            <Plus size={18} />
            <span>Create Story</span>
          </Link>

          <Link to="/drafts">
            <PenLine size={18} />
            <span>Drafts</span>
          </Link>

          <Link to="/analytics" className="active">
            <TrendingUp size={18} />
            <span>Analytics</span>
          </Link>
        </nav>

        <div className="sidebar-bottom">
          <Link to="/settings">
            <Settings size={18} />
            <span>Settings</span>
          </Link>

          <div className="writer-user">
            <div className="writer-avatar">DM</div>

            <div>
              <strong>Dev Malhotra</strong>
              <span>Writer</span>
            </div>
          </div>
        </div>
      </aside>

      {/* =========================================
          MAIN
      ========================================= */}

      <main className="analytics-main">
        {/* HEADER */}

        <header className="analytics-header">
          <div>
            <span className="eyebrow">WRITER ANALYTICS</span>

            <h1>See how your stories are doing.</h1>

            <p>
              Track your readers, understand your growth, and see what is
              resonating with your audience.
            </p>
          </div>

          <div className="analytics-actions">
            {/* TIME RANGE DROPDOWN */}

            <div
              className="analytics-period-wrapper"
              ref={dropdownRef}
            >
              <button
                type="button"
                className={`analytics-period ${
                  showTimeRange ? "open" : ""
                }`}
                onClick={() =>
                  setShowTimeRange((previous) => !previous)
                }
                aria-expanded={showTimeRange}
                aria-haspopup="listbox"
              >
                <span>{timeRange}</span>

                <ChevronDown
                  size={15}
                  className={
                    showTimeRange ? "rotate-chevron" : ""
                  }
                />
              </button>

              {showTimeRange && (
                <div
                  className="analytics-period-menu"
                  role="listbox"
                >
                  {timeRanges.map((range) => (
                    <button
                      type="button"
                      key={range}
                      role="option"
                      aria-selected={timeRange === range}
                      className={`analytics-period-option ${
                        timeRange === range ? "active" : ""
                      }`}
                      onClick={() => {
                        setTimeRange(range);
                        setShowTimeRange(false);
                      }}
                    >
                      <span>{range}</span>

                      {timeRange === range && (
                        <Check size={14} />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <Link
              to="/create-story"
              className="create-button"
            >
              <Plus size={17} />
              Create Story
            </Link>
          </div>
        </header>

        {/* =========================================
            STATS
        ========================================= */}

        <section className="analytics-stats">
          {stats.map((stat) => {
            const Icon = stat.icon;

            return (
              <div
                className="analytics-stat-card"
                key={stat.label}
              >
                <div className="stat-icon">
                  <Icon size={19} />
                </div>

                <div className="stat-content">
                  <span>{stat.label}</span>

                  <strong>{stat.value}</strong>

                  <small>
                    <TrendingUp size={13} />
                    {stat.change}
                  </small>
                </div>
              </div>
            );
          })}
        </section>

        {/* =========================================
            CHART
        ========================================= */}

        <section className="analytics-chart-card">
          <div className="card-heading">
            <div>
              <span className="section-label">
                PERFORMANCE
              </span>

              <h2>Story views</h2>

              <p>
                Total views across your published stories for{" "}
                <strong>{timeRange.toLowerCase()}</strong>.
              </p>
            </div>

            <div className="chart-total">
              <strong>{currentData.totalViews}</strong>

              <span>
                <TrendingUp size={13} />
                {currentData.totalGrowth}
              </span>
            </div>
          </div>

          <div className="chart-area">
            <div className="chart-y-labels">
              <span>100K</span>
              <span>75K</span>
              <span>50K</span>
              <span>25K</span>
              <span>0</span>
            </div>

            <div className="chart">
              <div className="chart-grid">
                <span />
                <span />
                <span />
                <span />
                <span />
              </div>

              <svg
                className="analytics-line"
                viewBox="0 0 900 280"
                preserveAspectRatio="none"
              >
                <defs>
                  <linearGradient
                    id="analyticsFill"
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1"
                  >
                    <stop
                      offset="0%"
                      stopOpacity="0.18"
                    />

                    <stop
                      offset="100%"
                      stopOpacity="0"
                    />
                  </linearGradient>
                </defs>

                <path
                  className="chart-fill"
                  d={chartFillPath}
                />

                <path
                  className="chart-line"
                  d={chartPath}
                />
              </svg>

              <div className="chart-months">
                {currentData.months.map((month) => (
                  <span key={month}>{month}</span>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* =========================================
            LOWER GRID
        ========================================= */}

        <section className="analytics-grid">
          {/* TOP STORIES */}

          <div className="analytics-panel">
            <div className="panel-heading">
              <div>
                <span className="section-label">
                  TOP STORIES
                </span>

                <h2>Best performing</h2>
              </div>

              <Link to="/my-stories">
                View all
                <ArrowUpRight size={15} />
              </Link>
            </div>

            <div className="top-stories">
              {stories.map((story, index) => (
                <div
                  className="top-story"
                  key={story.title}
                >
                  <div className="story-rank">
                    #{index + 1}
                  </div>

                  <div className="story-mini-cover">
                    <BookOpen size={19} />
                  </div>

                  <div className="story-info">
                    <div className="story-title-row">
                      <h3>{story.title}</h3>

                      <span>{story.category}</span>
                    </div>

                    <div className="story-metrics">
                      <span>
                        <Eye size={13} />
                        {story.views}
                      </span>

                      <span>
                        <Heart size={13} />
                        {story.likes}
                      </span>

                      <span>
                        <MessageCircle size={13} />
                        {story.comments}
                      </span>
                    </div>
                  </div>

                  <div className="story-growth">
                    <TrendingUp size={13} />
                    {story.growth}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ENGAGEMENT */}

          <div className="analytics-panel engagement-panel">
            <div className="panel-heading">
              <div>
                <span className="section-label">
                  ENGAGEMENT
                </span>

                <h2>Reader activity</h2>
              </div>
            </div>

            <div className="engagement-items">
              <div className="engagement-item">
                <div className="engagement-icon">
                  <Eye size={18} />
                </div>

                <div>
                  <strong>{currentData.views}</strong>
                  <span>Total views</span>
                </div>

                <b>{currentData.viewChange}</b>
              </div>

              <div className="engagement-item">
                <div className="engagement-icon">
                  <Heart size={18} />
                </div>

                <div>
                  <strong>{currentData.likes}</strong>
                  <span>Total likes</span>
                </div>

                <b>{currentData.likeChange}</b>
              </div>

              <div className="engagement-item">
                <div className="engagement-icon">
                  <MessageCircle size={18} />
                </div>

                <div>
                  <strong>{currentData.comments}</strong>
                  <span>Comments</span>
                </div>

                <b>{currentData.commentChange}</b>
              </div>

              <div className="engagement-item">
                <div className="engagement-icon">
                  <BookOpen size={18} />
                </div>

                <div>
                  <strong>74.8%</strong>
                  <span>Reader retention</span>
                </div>

                <b>+5.2%</b>
              </div>
            </div>
          </div>
        </section>

        {/* =========================================
            AUDIENCE
        ========================================= */}

        <section className="audience-card">
          <div>
            <span className="section-label">
              AUDIENCE
            </span>

            <h2>Your readers are growing.</h2>

            <p>
              More readers are discovering your work every month.
              Keep publishing consistently to build your audience.
            </p>
          </div>

          <div className="audience-number">
            <strong>{currentData.followers}</strong>

            <span>Followers</span>

            <b>
              <TrendingUp size={14} />
              {currentData.followerGrowth}
            </b>
          </div>
        </section>

        {/* =========================================
            CTA
        ========================================= */}

        <section className="analytics-cta">
          <div className="cta-icon">
            <PenLine size={21} />
          </div>

          <span className="section-label">
            KEEP CREATING
          </span>

          <h2>
            Great stories grow with every chapter.
          </h2>

          <p>
            Keep writing, keep publishing, and give your readers
            another world to discover.
          </p>

          <Link
            to="/create-story"
            className="create-button"
          >
            <Plus size={17} />
            Start Writing
          </Link>
        </section>
      </main>
    </div>
  );
}

export default Analytics;