import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowLeft,
  User,
  Shield,
  Bell,
  Globe,
  Lock,
  Save,
} from "lucide-react";

import "./Settings.css";

function Settings() {
  const [settings, setSettings] = useState({
    displayName: "Lumora Writer",
    username: "lumorawriter",
    bio: "Writer on Lumora. Sharing stories, ideas and worlds.",
    email: "writer@example.com",
    language: "English",
    profileVisibility: "Public",
    emailNotifications: true,
    commentNotifications: true,
    followerNotifications: true,
    showReadingActivity: true,
  });

  const [saved, setSaved] = useState(true);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setSettings((current) => ({
      ...current,
      [name]: type === "checkbox" ? checked : value,
    }));

    setSaved(false);
  };

  const handleSave = () => {
    setSaved(true);
  };

  return (
    <div className="writer-settings-page">
      {/* TOP BAR */}
      <header className="settings-topbar">
        <Link to="/writer/dashboard" className="settings-back">
          <ArrowLeft size={16} />
          <span>Back to Dashboard</span>
        </Link>

        <div className="settings-title">
          <span>Writer</span>
          <strong>Settings</strong>
        </div>

        <div
          className={`settings-save-status ${
            saved ? "saved" : "changed"
          }`}
        >
          <span />
          {saved ? "All changes saved" : "Unsaved changes"}
        </div>
      </header>

      <main className="writer-settings-main">
        {/* INTRO */}
        <div className="settings-intro">
          <span className="settings-eyebrow">ACCOUNT SETTINGS</span>

          <h1>Manage your writer space.</h1>

          <p>
            Update your profile, privacy and notification preferences from
            one place.
          </p>
        </div>

        <div className="settings-layout">
          {/* LEFT NAV */}
          <aside className="settings-nav">
            <a href="#profile" className="settings-nav-item active">
              <User size={16} />
              <span>Profile</span>
            </a>

            <a href="#privacy" className="settings-nav-item">
              <Shield size={16} />
              <span>Privacy</span>
            </a>

            <a href="#notifications" className="settings-nav-item">
              <Bell size={16} />
              <span>Notifications</span>
            </a>

            <a href="#preferences" className="settings-nav-item">
              <Globe size={16} />
              <span>Preferences</span>
            </a>
          </aside>

          {/* CONTENT */}
          <section className="settings-content">
            {/* PROFILE */}
            <section className="settings-card" id="profile">
              <div className="settings-card-heading">
                <div className="settings-card-icon">
                  <User size={18} />
                </div>

                <div>
                  <h2>Profile information</h2>
                  <p>
                    This information will appear on your public writer
                    profile.
                  </p>
                </div>
              </div>

              <div className="settings-avatar-row">
                <div className="settings-avatar">LW</div>

                <div>
                  <strong>Profile picture</strong>
                  <p>
                    JPG, PNG or WEBP. Recommended size 400 × 400.
                  </p>

                  <button
                    type="button"
                    className="outline-small-button"
                  >
                    Change picture
                  </button>
                </div>
              </div>

              <div className="settings-form-grid">
                <div className="settings-field">
                  <label htmlFor="displayName">
                    Display name
                  </label>

                  <input
                    id="displayName"
                    name="displayName"
                    value={settings.displayName}
                    onChange={handleChange}
                  />
                </div>

                <div className="settings-field">
                  <label htmlFor="username">
                    Username
                  </label>

                  <div className="username-input">
                    <span>@</span>

                    <input
                      id="username"
                      name="username"
                      value={settings.username}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </div>

              <div className="settings-field">
                <label htmlFor="bio">Bio</label>

                <textarea
                  id="bio"
                  name="bio"
                  value={settings.bio}
                  onChange={handleChange}
                  rows="4"
                  maxLength="250"
                />

                <small>
                  {settings.bio.length}/250
                </small>
              </div>

              <div className="settings-field">
                <label htmlFor="email">
                  Email address
                </label>

                <input
                  id="email"
                  name="email"
                  type="email"
                  value={settings.email}
                  onChange={handleChange}
                />

                <small>
                  Your email is not publicly displayed.
                </small>
              </div>
            </section>

            {/* PRIVACY */}
            <section className="settings-card" id="privacy">
              <div className="settings-card-heading">
                <div className="settings-card-icon">
                  <Lock size={18} />
                </div>

                <div>
                  <h2>Privacy</h2>
                  <p>
                    Control how readers can see your activity.
                  </p>
                </div>
              </div>

              <div className="settings-option">
                <div className="settings-option-text">
                  <strong>Profile visibility</strong>

                  <span>
                    Decide who can view your writer profile.
                  </span>
                </div>

                <select
                  name="profileVisibility"
                  value={settings.profileVisibility}
                  onChange={handleChange}
                >
                  <option value="Public">Public</option>
                  <option value="Private">Private</option>
                </select>
              </div>

              <div className="settings-option">
                <div className="settings-option-text">
                  <strong>Show reading activity</strong>

                  <span>
                    Allow readers to see stories you are currently
                    reading.
                  </span>
                </div>

                <label className="toggle">
                  <input
                    type="checkbox"
                    name="showReadingActivity"
                    checked={settings.showReadingActivity}
                    onChange={handleChange}
                  />

                  <span className="toggle-slider" />
                </label>
              </div>
            </section>

            {/* NOTIFICATIONS */}
            <section
              className="settings-card"
              id="notifications"
            >
              <div className="settings-card-heading">
                <div className="settings-card-icon">
                  <Bell size={18} />
                </div>

                <div>
                  <h2>Notifications</h2>
                  <p>
                    Choose what you want to hear about.
                  </p>
                </div>
              </div>

              <div className="settings-option">
                <div className="settings-option-text">
                  <strong>Email notifications</strong>

                  <span>
                    Receive important account updates by email.
                  </span>
                </div>

                <label className="toggle">
                  <input
                    type="checkbox"
                    name="emailNotifications"
                    checked={settings.emailNotifications}
                    onChange={handleChange}
                  />

                  <span className="toggle-slider" />
                </label>
              </div>

              <div className="settings-option">
                <div className="settings-option-text">
                  <strong>Comment notifications</strong>

                  <span>
                    Get notified when readers comment on your
                    stories.
                  </span>
                </div>

                <label className="toggle">
                  <input
                    type="checkbox"
                    name="commentNotifications"
                    checked={settings.commentNotifications}
                    onChange={handleChange}
                  />

                  <span className="toggle-slider" />
                </label>
              </div>

              <div className="settings-option">
                <div className="settings-option-text">
                  <strong>Follower notifications</strong>

                  <span>
                    Get notified when someone follows your profile.
                  </span>
                </div>

                <label className="toggle">
                  <input
                    type="checkbox"
                    name="followerNotifications"
                    checked={settings.followerNotifications}
                    onChange={handleChange}
                  />

                  <span className="toggle-slider" />
                </label>
              </div>
            </section>

            {/* PREFERENCES */}
            <section
              className="settings-card"
              id="preferences"
            >
              <div className="settings-card-heading">
                <div className="settings-card-icon">
                  <Globe size={18} />
                </div>

                <div>
                  <h2>Preferences</h2>
                  <p>
                    Customize your Lumora experience.
                  </p>
                </div>
              </div>

              <div className="settings-option">
                <div className="settings-option-text">
                  <strong>Content language</strong>

                  <span>
                    Choose the language used for your writing
                    experience.
                  </span>
                </div>

                <select
                  name="language"
                  value={settings.language}
                  onChange={handleChange}
                >
                  <option value="English">English</option>
                  <option value="Hindi">Hindi</option>
                  <option value="Marathi">Marathi</option>
                </select>
              </div>
            </section>

            {/* SAVE */}
            <div className="settings-actions">
              <span>
                {saved
                  ? "Your settings are up to date."
                  : "You have unsaved changes."}
              </span>

              <button
                type="button"
                className="settings-save-button"
                onClick={handleSave}
              >
                <Save size={15} />
                Save changes
              </button>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

export default Settings;