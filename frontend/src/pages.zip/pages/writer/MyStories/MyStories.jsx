import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";

import {
  BookOpen,
  Plus,
  Search,
  MoreHorizontal,
  Eye,
  Heart,
  MessageCircle,
  Edit3,
  BarChart3,
  ChevronRight,
} from "lucide-react";

import "./MyStories.css";

import lumoraLogo from "../../../assets/logo/lumora-logo-bold.svg";
import storyService from "../../../services/stories/storyService";

const demoStories = [
  {
    id: "the-last-kingdom",
    title: "The Last Kingdom",
    category: "Fantasy",
    description:
      "A fallen prince returns to a kingdom that no longer remembers his name.",
    status: "Published",
    views: "245K",
    likes: "18.2K",
    comments: "1.4K",
    chapters: 24,
    updated: "2 days ago",
  },
  {
    id: "under-a-dead-sky",
    title: "Under a Dead Sky",
    category: "Horror",
    description:
      "The world ended quietly. What came after did not.",
    status: "Published",
    views: "198K",
    likes: "15.4K",
    comments: "2.1K",
    chapters: 18,
    updated: "5 days ago",
  },
  {
    id: "the-silent-room",
    title: "The Silent Room",
    category: "Mystery",
    description:
  "Every house has a secret. This one has a room no one is allowed to enter.",
    status: "Draft",
    views: "17.6K",
    likes: "1.3K",
    comments: "710",
    chapters: 8,
    updated: "Yesterday",
  },
  {
    id: "beyond-the-stars",
    title: "Beyond the Stars",
    category: "Sci-Fi",
    description:
      "Humanity's first journey beyond the solar system changes everything.",
    status: "Published",
    views: "154K",
    likes: "11.6K",
    comments: "1.8K",
    chapters: 16,
    updated: "1 week ago",
  },
  {
    id: "where-shadows-sleep",
    title: "Where Shadows Sleep",
    category: "Fantasy",
    description:
      "A forgotten kingdom hides a secret that should never be awakened.",
    status: "Draft",
    views: "8.7K",
    likes: "620",
    comments: "250",
    chapters: 5,
    updated: "3 days ago",
  },
];

function StoryIcon({ category }) {
  return (
    <div className="my-story-icon">
      <BookOpen size={20} strokeWidth={2} />
      <span>{category}</span>
    </div>
  );
}

function MyStories() {

  const [stories, setStories] = useState(demoStories);
  const [searchQuery, setSearchQuery] = useState("");
const [activeFilter, setActiveFilter] = useState("All");

const [openMenu, setOpenMenu] = useState(null);

useEffect(() => {
  const loadStories = async () => {
    try {
      const response = await storyService.getMyStories();
      setStories(response.stories.map((story) => ({
        ...story,
        id: story._id,
        description: story.shortDescription,
        likes: story.likes?.length || 0,
        chapters: story.chapterCount || 0,
        updated: new Date(story.updatedAt).toLocaleDateString(),
      })));
    } catch {
      setStories([]);
    }
  };

  loadStories();
}, []);

const filteredStories = useMemo(() => {
  const query = searchQuery.trim().toLowerCase();

  return stories.filter((story) => {
    const matchesSearch =
      !query ||
      story.title.toLowerCase().includes(query) ||
      story.category.toLowerCase().includes(query) ||
      story.description.toLowerCase().includes(query);

    const matchesFilter =
      activeFilter === "All" ||
      story.status.toLowerCase() === activeFilter.toLowerCase();

    return matchesSearch && matchesFilter;
  });
}, [searchQuery, activeFilter]);

  return (
    <div className="writer-layout">
      {/* Sidebar */}
      <aside className="writer-sidebar">
       <Link to="/" className="writer-brand">
  <img
    src={lumoraLogo}
    alt="Lumora"
    className="writer-brand-logo"
  />
</Link>

        <nav className="writer-nav">
          <Link to="/dashboard" className="writer-nav-item">
            <BookOpen size={18} />
            <span>Dashboard</span>
          </Link>

          <Link
            to="/my-stories"
            className="writer-nav-item active"
          >
            <BookOpen size={18} />
            <span>My Stories</span>
          </Link>

          <Link to="/create-story" className="writer-nav-item">
            <Plus size={18} />
            <span>Create Story</span>
          </Link>

          <Link to="/drafts" className="writer-nav-item">
            <Edit3 size={18} />
            <span>Drafts</span>
          </Link>

          <Link to="/analytics" className="writer-nav-item">
            <BarChart3 size={18} />
            <span>Analytics</span>
          </Link>
        </nav>

        <div className="writer-sidebar-bottom">
          <Link to="/settings" className="writer-nav-item">
            <MoreHorizontal size={18} />
            <span>Settings</span>
          </Link>

          <div className="writer-user">
            <div className="writer-avatar">DM</div>

            <div>
              <strong>Dev Malhotra</strong>
              <span>Writer</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="my-stories-main">
        <div className="my-stories-container">

          {/* Header */}
          <header className="my-stories-header">
            <div>
              <span className="section-label">YOUR WORK</span>

              <h1>My Stories</h1>

              <p>
                Manage your stories, chapters, drafts and published work.
              </p>
            </div>

            <Link to="/create-story" className="create-story-btn">
              <Plus size={18} />
              Create Story
            </Link>
          </header>

          {/* Toolbar */}
          <section className="stories-toolbar">
            <div className="story-search">
              <Search size={18} />
              <input
  type="text"
  placeholder="Search your stories..."
  value={searchQuery}
  onChange={(e) => setSearchQuery(e.target.value)}
/>
            </div>

           <div className="story-filters">
  <button
    type="button"
    className={`filter-btn ${
      activeFilter === "All" ? "active" : ""
    }`}
    onClick={() => setActiveFilter("All")}
  >
    All <span>{stories.length}</span>
  </button>

  <button
    type="button"
    className={`filter-btn ${
      activeFilter === "Published" ? "active" : ""
    }`}
    onClick={() => setActiveFilter("Published")}
  >
    Published{" "}
    <span>
      {stories.filter((story) => story.status === "Published").length}
    </span>
  </button>

  <button
    type="button"
    className={`filter-btn ${
      activeFilter === "Draft" ? "active" : ""
    }`}
    onClick={() => setActiveFilter("Draft")}
  >
    Drafts{" "}
    <span>
      {stories.filter((story) => story.status === "Draft").length}
    </span>
  </button>
</div>
          </section>

          {/* Stories */}
          <section className="stories-section">
            <div className="stories-section-heading">
              <div>
                <span className="section-label">STORIES</span>
                <h2>All your stories</h2>
              </div>

              <span className="story-count">
  {filteredStories.length}{" "}
  {filteredStories.length === 1 ? "story" : "stories"}
</span>
            </div>

            <div className="stories-list">
  {filteredStories.length === 0 ? (
    <div className="stories-empty">
      <Search size={22} />

      <h3>No stories found</h3>

      <p>
        Try a different search or select another filter.
      </p>
    </div>
  ) : (
    filteredStories.map((story) => (
      <article
        className="story-row"
        key={story.id}
      >
        <StoryIcon category={story.category} />

        <div className="story-row-content">
          <div className="story-title-line">
            <h3>{story.title}</h3>

            <span
              className={`story-status ${story.status.toLowerCase()}`}
            >
              {story.status}
            </span>
          </div>

          <p className="story-description">
            {story.description}
          </p>

          <div className="story-meta">
            <span>
              <BookOpen size={14} />
              {story.chapters} chapters
            </span>

            <span>
              <Eye size={14} />
              {story.views}
            </span>

            <span>
              <Heart size={14} />
              {story.likes}
            </span>

            <span>
              <MessageCircle size={14} />
              {story.comments}
            </span>

            <span className="story-updated">
              Updated {story.updated}
            </span>
          </div>
        </div>

        <div className="story-actions">
  <Link
    to={`/stories/${story.id}`}
    className="story-action"
    title="View story"
  >
    <Eye size={17} />
  </Link>

  <Link
    to={`/writer/story/${story.id}/edit`}
    className="story-action"
    title="Edit story"
  >
    <Edit3 size={17} />
  </Link>

  <div className="story-more-wrapper">
    <button
      className="story-action"
      type="button"
      title="More options"
      onClick={() =>
        setOpenMenu(
          openMenu === story.id ? null : story.id
        )
      }
    >
      <MoreHorizontal size={18} />
    </button>

    {openMenu === story.id && (
      <div className="story-more-menu">
        <Link to={`/stories/${story.id}`
      }>
          View Story
        </Link>

        <Link to={`/writer/story/${story.id}/edit`}>
          Edit Story
        </Link>

        <button
          type="button"
          onClick={() => setOpenMenu(null)}
        >
          Close
        </button>
      </div>
    )}
  </div>
</div>

        <ChevronRight
          className="story-mobile-arrow"
          size={19}
        />
      </article>
    ))
  )}
</div>
          </section>

          {/* Bottom CTA */}
          <section className="my-stories-cta">
            <div className="cta-icon">
              <Edit3 size={22} />
            </div>

            <span className="section-label">KEEP CREATING</span>

            <h2>Have another story in you?</h2>

            <p>
              Start writing something new and share your next world
              with Lumora readers.
            </p>

            <Link to="/create-story" className="cta-button">
              <Plus size={17} />
              Start Writing
            </Link>
          </section>

        </div>
      </main>
    </div>
  );
}

export default MyStories;
