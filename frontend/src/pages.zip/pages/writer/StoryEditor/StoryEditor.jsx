import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowLeft,
  BookOpen,
  Save,
  Eye,
  Settings,
  ChevronDown,
  Check,
} from "lucide-react";

import "./StoryEditor.css";

function StoryEditor() {
  const title = "The Silent Room";

  const [chapterTitle, setChapterTitle] = useState(
    "Chapter 1 — The Door"
  );

  const [content, setContent] = useState(
    `The house had been empty for years.

Everyone in the village knew the story.

No one entered the house after sunset. No one even went near the old wooden door.

But tonight, something was different.

A faint light was coming from inside.

Dev stood at the end of the corridor and stared at the door.

He had promised himself that he would never open it.

Then he heard three quiet knocks.

From the other side.

He stopped breathing.

Another knock.

This time, louder.

Dev slowly reached for the handle.

The door was already unlocked.`
  );

  const [isSaved, setIsSaved] = useState(true);
  const [showPreview, setShowPreview] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const handleContentChange = (event) => {
    setContent(event.target.value);
    setIsSaved(false);
  };

  const handleSave = () => {
    setIsSaved(true);
  };

  const handlePublish = () => {
    setIsSaved(true);
    alert("Chapter is ready to publish.");
  };

  const wordCount = content.trim()
    ? content.trim().split(/\s+/).length
    : 0;

  const characterCount = content.length;

  return (
    <div className="story-editor-page">
      {/* =========================================
          TOP BAR
          ========================================= */}

      <header className="editor-topbar">
        <div className="editor-top-left">
          <Link to="/writer/dashboard" className="editor-back">
            <ArrowLeft size={16} />
            <span>Back to Dashboard</span>
          </Link>

          <div className="editor-divider" />

          <div className="editor-story-info">
            <BookOpen size={17} />
            <span>{title}</span>
          </div>
        </div>

        <div className="editor-top-right">
          <div className="save-status">
            <span
              className={`save-status-dot ${
                isSaved ? "saved" : "unsaved"
              }`}
            />

            {isSaved ? "Saved" : "Unsaved changes"}
          </div>

          <button
            type="button"
            className="editor-icon-button"
            onClick={() => setShowPreview(!showPreview)}
            title="Preview"
          >
            <Eye size={17} />
          </button>

          <button
            type="button"
            className="editor-icon-button"
            onClick={() => setShowSettings(!showSettings)}
            title="Settings"
          >
            <Settings size={17} />
          </button>

          <button
            type="button"
            className="editor-save-button"
            onClick={handleSave}
          >
            <Save size={15} />
            Save
          </button>

          <button
            type="button"
            className="editor-publish-button"
            onClick={handlePublish}
          >
            Publish
          </button>
        </div>
      </header>

      {/* =========================================
          EDITOR BODY
          ========================================= */}

      <main className="story-editor-main">
        <div className="editor-layout">
          {/* =====================================
              LEFT SIDEBAR
              ===================================== */}

          <aside className="editor-sidebar">
            <div className="sidebar-section">
              <span className="sidebar-label">STORY</span>

              <div className="sidebar-story-title">
                <BookOpen size={16} />
                <span>{title}</span>
              </div>
            </div>

            <div className="sidebar-section">
              <div className="sidebar-section-header">
                <span className="sidebar-label">CHAPTERS</span>

                <button type="button" className="chapter-add">
                  +
                </button>
              </div>

              <button
                type="button"
                className="chapter-item active"
              >
                <span className="chapter-number">01</span>

                <span className="chapter-name">
                  The Door
                </span>
              </button>

              <button
                type="button"
                className="chapter-item"
              >
                <span className="chapter-number">02</span>

                <span className="chapter-name">
                  The Stranger
                </span>
              </button>

              <button
                type="button"
                className="chapter-item"
              >
                <span className="chapter-number">03</span>

                <span className="chapter-name">
                  The Secret
                </span>
              </button>

              <button
                type="button"
                className="chapter-item"
              >
                <span className="chapter-number">04</span>

                <span className="chapter-name">
                  Into the Room
                </span>
              </button>
            </div>

            <div className="sidebar-bottom">
              <button
                type="button"
                className="sidebar-settings"
                onClick={() => setShowSettings(!showSettings)}
              >
                <Settings size={16} />
                <span>Chapter settings</span>
              </button>
            </div>
          </aside>

          {/* =====================================
              CENTER EDITOR
              ===================================== */}

          <section className="editor-workspace">
            <div className="chapter-heading">
              <span className="editor-eyebrow">
                EDITING CHAPTER 01
              </span>

              <input
                type="text"
                value={chapterTitle}
                onChange={(event) => {
                  setChapterTitle(event.target.value);
                  setIsSaved(false);
                }}
                className="chapter-title-input"
                aria-label="Chapter title"
              />

              <div className="chapter-meta">
                <span>{wordCount} words</span>
                <span>•</span>
                <span>{characterCount} characters</span>
              </div>
            </div>

            <div className="editor-paper">
              <textarea
                value={content}
                onChange={handleContentChange}
                className="story-content-editor"
                spellCheck="true"
                aria-label="Story content"
              />
            </div>

            <div className="editor-bottom-bar">
              <div className="editor-stats">
                <span>{wordCount} words</span>
                <span>•</span>
                <span>Draft</span>
              </div>

              <div className="editor-actions">
                <button
                  type="button"
                  className="secondary-editor-button"
                  onClick={handleSave}
                >
                  <Check size={15} />
                  Save draft
                </button>

                <button
                  type="button"
                  className="primary-editor-button"
                  onClick={handlePublish}
                >
                  Publish chapter
                </button>
              </div>
            </div>
          </section>

          {/* =====================================
              RIGHT PANEL
              ===================================== */}

          <aside className="editor-right-panel">
            <div className="editor-panel-card">
              <div className="panel-heading">
                <div>
                  <span className="panel-eyebrow">
                    CHAPTER
                  </span>

                  <h3>Publishing</h3>
                </div>

                <ChevronDown size={16} />
              </div>

              <div className="panel-field">
                <label>Status</label>

                <div className="panel-select">
                  <span>Draft</span>
                  <ChevronDown size={14} />
                </div>
              </div>

              <div className="panel-field">
                <label>Visibility</label>

                <div className="panel-select">
                  <span>Public</span>
                  <ChevronDown size={14} />
                </div>
              </div>

              <div className="panel-field">
                <label>Chapter number</label>

                <input
                  type="text"
                  value="1"
                  readOnly
                />
              </div>
            </div>

            <div className="editor-panel-card">
              <div className="panel-heading">
                <div>
                  <span className="panel-eyebrow">
                    READING
                  </span>

                  <h3>Reader preview</h3>
                </div>
              </div>

              <div className="reader-preview">
                <div className="reader-preview-icon">
                  <BookOpen size={18} />
                </div>

                <strong>{chapterTitle}</strong>

                <span>
                  See how your chapter will appear
                  to readers.
                </span>

                <button
                  type="button"
                  onClick={() => setShowPreview(true)}
                >
                  Preview chapter
                  <Eye size={14} />
                </button>
              </div>
            </div>

            <div className="editor-panel-card editor-tip-card">
              <span className="panel-eyebrow">
                WRITING TIP
              </span>

              <h3>Keep readers curious.</h3>

              <p>
                End chapters with a question,
                discovery, or moment that makes
                readers want to continue.
              </p>
            </div>
          </aside>
        </div>
      </main>

      {/* =========================================
          PREVIEW MODAL
          ========================================= */}

      {showPreview && (
        <div
          className="editor-modal-overlay"
          onClick={() => setShowPreview(false)}
        >
          <div
            className="editor-preview-modal"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="preview-modal-header">
              <div>
                <span className="panel-eyebrow">
                  READER PREVIEW
                </span>

                <h2>{chapterTitle}</h2>
              </div>

              <button
                type="button"
                className="preview-close"
                onClick={() => setShowPreview(false)}
              >
                ×
              </button>
            </div>

            <article className="preview-story-content">
              {content.split("\n\n").map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </article>
          </div>
        </div>
      )}

      {/* =========================================
          SETTINGS PANEL
          ========================================= */}

      {showSettings && (
        <div className="editor-settings-panel">
          <div className="settings-panel-header">
            <div>
              <span className="panel-eyebrow">
                SETTINGS
              </span>

              <h3>Chapter settings</h3>
            </div>

            <button
              type="button"
              onClick={() => setShowSettings(false)}
            >
              ×
            </button>
          </div>

          <div className="settings-option">
            <div>
              <strong>Allow comments</strong>

              <span>
                Let readers comment on this chapter.
              </span>
            </div>

            <input type="checkbox" defaultChecked />
          </div>

          <div className="settings-option">
            <div>
              <strong>Show chapter publicly</strong>

              <span>
                Make this chapter visible to readers.
              </span>
            </div>

            <input type="checkbox" defaultChecked />
          </div>
        </div>
      )}
    </div>
  );
}

export default StoryEditor;