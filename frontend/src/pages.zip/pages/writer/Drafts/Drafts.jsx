import { useMemo, useState } from "react";
import { Link } from "react-router-dom";

import {
  BookOpen,
  Plus,
  Search,
  MoreHorizontal,
  Edit3,
  Eye,
  Clock3,
} from "lucide-react";

import lumoraLogo from "../../../assets/logo/lumora-logo-bold.svg";

import "./Drafts.css";

const drafts = [
  {
    id: "the-silent-room",
    title: "The Silent Room",
    category: "Mystery",
    description:
      "Every house has a secret. This one has a room no one is allowed to enter.",
    chapters: 8,
    views: "17.6K",
    likes: "1.3K",
    comments: "710",
    updated: "Yesterday",
    progress: 78,
  },
  {
    id: "where-shadows-sleep",
    title: "Where Shadows Sleep",
    category: "Fantasy",
    description:
      "A forgotten kingdom hides a secret that should never be awakened.",
    chapters: 5,
    views: "8.7K",
    likes: "620",
    comments: "250",
    updated: "3 days ago",
    progress: 54,
  },
  {
    id: "the-last-signal",
    title: "The Last Signal",
    category: "Sci-Fi",
    description:
      "A mysterious signal reaches Earth from somewhere beyond the stars.",
    chapters: 4,
    views: "4.2K",
    likes: "310",
    comments: "92",
    updated: "1 week ago",
    progress: 42,
  },
];

function Drafts() {

const [searchQuery, setSearchQuery] = useState("");
const [sortBy, setSortBy] = useState("recent");

const [openMenu, setOpenMenu] = useState(null);

const filteredDrafts = useMemo(() => {
  const query = searchQuery.trim().toLowerCase();

  const result = drafts.filter((draft) => {
    return (
      !query ||
      draft.title.toLowerCase().includes(query) ||
      draft.category.toLowerCase().includes(query) ||
      draft.description.toLowerCase().includes(query)
    );
  });

  if (sortBy === "progress-high") {
    return [...result].sort(
      (a, b) => b.progress - a.progress
    );
  }

  if (sortBy === "progress-low") {
    return [...result].sort(
      (a, b) => a.progress - b.progress
    );
  }

  return result;
}, [searchQuery, sortBy]);

return (
    <div className="writer-layout drafts-page">
      {/* Sidebar */}
      <aside className="writer-sidebar">
       <Link to="/" className="writer-brand">
  <img
    src={lumoraLogo}
    alt="Lumora"
    className="writer-brand-logo"
  />
</Link>

        <nav className="writer-nav">
          <Link to="/dashboard" className="writer-nav-item">
            <BookOpen size={18} />
            <span>Dashboard</span>
          </Link>

          <Link to="/my-stories" className="writer-nav-item">
            <BookOpen size={18} />
            <span>My Stories</span>
          </Link>

          <Link to="/create-story" className="writer-nav-item">
            <Plus size={18} />
            <span>Create Story</span>
          </Link>

          <Link
            to="/drafts"
            className="writer-nav-item active"
          >
            <Edit3 size={18} />
            <span>Drafts</span>
          </Link>

          <Link to="/analytics" className="writer-nav-item">
            <Clock3 size={18} />
            <span>Analytics</span>
          </Link>
        </nav>

        <div className="writer-sidebar-bottom">
          <Link to="/settings" className="writer-nav-item">
            <MoreHorizontal size={18} />
            <span>Settings</span>
          </Link>

          <div className="writer-user">
            <div className="writer-avatar">DM</div>

            <div>
              <strong>Dev Malhotra</strong>
              <span>Writer</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="drafts-main">
        <div className="drafts-container">

          {/* Header */}
          <header className="drafts-header">
            <div>
              <span className="section-label">
                YOUR WORK
              </span>

              <h1>Drafts</h1>

              <p>
                Continue working on stories that are still taking shape.
              </p>
            </div>

            <Link
              to="/create-story"
              className="create-story-btn"
            >
              <Plus size={18} />
              Create Story
            </Link>
          </header>

          {/* Toolbar */}
          <section className="drafts-toolbar">
            <div className="draft-search">
              <Search size={18} />

              <input
  type="text"
  placeholder="Search your drafts..."
  value={searchQuery}
  onChange={(e) => setSearchQuery(e.target.value)}
/>
            </div>

            <div className="draft-sort">
              <span>Sort by</span>

              <select
  value={sortBy}
  onChange={(e) => setSortBy(e.target.value)}
  className="draft-sort-select"
>
  <option value="recent">
    Recently updated
  </option>

  <option value="progress-high">
    Highest progress
  </option>

  <option value="progress-low">
    Lowest progress
  </option>
</select>
            </div>
          </section>

          {/* Draft count */}
          <section className="drafts-section">
            <div className="drafts-heading">
              <div>
                <span className="section-label">
                  IN PROGRESS
                </span>

                <h2>Your drafts</h2>
              </div>

              <span className="draft-count">
  {filteredDrafts.length}{" "}
  {filteredDrafts.length === 1 ? "draft" : "drafts"}
</span>
            </div>

            <div className="drafts-list">
  {filteredDrafts.length === 0 ? (
    <div className="drafts-empty">
      <Search size={22} />

      <h3>No drafts found</h3>

      <p>
        Try a different search.
      </p>
    </div>
  ) : (
    filteredDrafts.map((draft) => (
      <article
        className="draft-card"
        key={draft.id}
      >
        <div className="draft-cover">
          <BookOpen size={22} />
          <span>{draft.category}</span>
        </div>

        <div className="draft-content">
          <div className="draft-title-row">
            <h3>{draft.title}</h3>

            <span className="draft-badge">
              Draft
            </span>
          </div>

          <p className="draft-description">
            {draft.description}
          </p>

          <div className="draft-meta">
            <span>
              <BookOpen size={14} />
              {draft.chapters} chapters
            </span>

            <span>
              <Eye size={14} />
              {draft.views}
            </span>

            <span>
              <Clock3 size={14} />
              Updated {draft.updated}
            </span>
          </div>

          <div className="draft-progress">
            <div className="progress-header">
              <span>Writing progress</span>

              <strong>
                {draft.progress}%
              </strong>
            </div>

            <div className="progress-track">
              <div
                className="progress-fill"
                style={{
                  width: `${draft.progress}%`,
                }}
              />
            </div>
          </div>
        </div>

        <div className="draft-actions">
          <Link
            to={`/writer/story/${draft.id}/edit`}
            className="draft-edit-btn"
          >
            <Edit3 size={16} />
            Continue writing
          </Link>
<div className="draft-more-wrapper">
  <button
    type="button"
    className="draft-more-btn"
    title="More options"
    onClick={() =>
      setOpenMenu(
        openMenu === draft.id ? null : draft.id
      )
    }
  >
    <MoreHorizontal size={18} />
  </button>

  {openMenu === draft.id && (
    <div className="draft-more-menu">
      <Link
        to={`/writer/story/${draft.id}/edit`}
        onClick={() => setOpenMenu(null)}
      >
        <Edit3 size={14} />
        Continue Writing
      </Link>

      <Link
        to={`/stories/${draft.id}`}
        onClick={() => setOpenMenu(null)}
      >
        <Eye size={14} />
        View Story
      </Link>

      <button
        type="button"
        onClick={() => setOpenMenu(null)}
      >
        Close
      </button>
    </div>
  )}
</div>
        </div>
      </article>
    ))
  )}
</div>
          </section>

          {/* Empty-style CTA */}
          <section className="drafts-cta">
            <div className="drafts-cta-icon">
              <Plus size={22} />
            </div>

            <span className="section-label">
              START SOMETHING NEW
            </span>

            <h2>Have another idea?</h2>

            <p>
              Create a new story and turn your next idea into
              something readers can discover.
            </p>

            <Link
              to="/create-story"
              className="cta-button"
            >
              <Plus size={17} />
              Start a New Story
            </Link>
          </section>

        </div>
      </main>
    </div>
  );
}

export default Drafts;
