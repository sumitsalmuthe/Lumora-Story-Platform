import { Link } from "react-router-dom";
import {
  BookOpen,
  Eye,
  Heart,
  MessageCircle,
  Plus,
  ArrowRight,
  TrendingUp,
  Edit3,
  MoreHorizontal,
  Settings as SettingsIcon,
} from "lucide-react";

import "./Dashboard.css";

import lumoraLogo from "../../../assets/logo/lumora-logo-bold.svg";

import "./Dashboard.css";

const recentStories = [
  {
    id: "the-last-kingdom",
    title: "The Last Kingdom",
    category: "Fantasy",
    status: "Published",
    views: "245K",
    likes: "18.2K",
    comments: "1.4K",
    updated: "2 days ago",
  },
  {
    id: "under-a-dead-sky",
    title: "Under a Dead Sky",
    category: "Horror",
    status: "Published",
    views: "198K",
    likes: "15.4K",
    comments: "2.1K",
    updated: "5 days ago",
  },
  {
    id: "the-silent-room",
    title: "The Silent Room",
    category: "Mystery",
    status: "Draft",
    views: "17.6K",
    likes: "1.3K",
    comments: "710",
    updated: "Yesterday",
  },
];

const activity = [
  {
    title: "The Last Kingdom",
    text: "Chapter 24 was published.",
    time: "2 hours ago",
  },
  {
    title: "Under a Dead Sky",
    text: "Chapter 18 received 1,200 new views.",
    time: "Yesterday",
  },
  {
    title: "The Silent Room",
    text: "Draft was updated.",
    time: "2 days ago",
  },
];

function Dashboard() {
  return (
    <div className="writer-dashboard">
      {/* Sidebar */}
      <aside className="writer-sidebar">
        <Link to="/" className="writer-logo">
  <img
    src={lumoraLogo}
    alt="Lumora"
    className="writer-logo-image"
  />
</Link>

        <nav className="writer-nav">
          <Link to="/writer/dashboard" className="writer-nav__item active">
            <BookOpen size={18} />
            <span>Dashboard</span>
          </Link>

          <Link to="/my-stories" className="writer-nav__item">
            <BookOpen size={18} />
            <span>My Stories</span>
          </Link>

          <Link to="/create-story" className="writer-nav__item">
            <Plus size={18} />
            <span>Create Story</span>
          </Link>

          <Link to="/drafts" className="writer-nav__item">
            <Edit3 size={18} />
            <span>Drafts</span>
          </Link>

          <Link to="/analytics" className="writer-nav__item">
            <TrendingUp size={18} />
            <span>Analytics</span>
          </Link>
        </nav>

        <div className="writer-sidebar__bottom">
          <Link to="/settings" className="writer-nav__item">
  <SettingsIcon size={18} />
  <span>Settings</span>
</Link>

          <div className="writer-user">
            <div className="writer-user__avatar">DM</div>

            <div className="writer-user__info">
              <strong>Dev Malhotra</strong>
              <span>Writer</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="writer-main">
        {/* Top bar */}
        <header className="writer-topbar">
          <div>
            <span className="writer-eyebrow">WRITER DASHBOARD</span>
            <h1>Welcome back, Dev.</h1>
            <p>
              Here's what's happening with your stories today.
            </p>
          </div>

          <Link to="/create-story" className="writer-primary-btn">
            <Plus size={17} />
            Create Story
          </Link>
        </header>

        {/* Stats */}
        <section className="writer-stats">
          <div className="writer-stat-card">
            <div className="writer-stat-icon">
              <BookOpen size={18} />
            </div>

            <div>
              <span>Total Stories</span>
              <strong>12</strong>
            </div>
          </div>

          <div className="writer-stat-card">
            <div className="writer-stat-icon">
              <Eye size={18} />
            </div>

            <div>
              <span>Total Views</span>
              <strong>924K</strong>
            </div>
          </div>

          <div className="writer-stat-card">
            <div className="writer-stat-icon">
              <Heart size={18} />
            </div>

            <div>
              <span>Total Likes</span>
              <strong>68.4K</strong>
            </div>
          </div>

          <div className="writer-stat-card">
            <div className="writer-stat-icon">
              <MessageCircle size={18} />
            </div>

            <div>
              <span>Comments</span>
              <strong>9.2K</strong>
            </div>
          </div>
        </section>

        {/* Content grid */}
        <section className="writer-content-grid">
          {/* Stories */}
          <div className="writer-panel writer-panel--stories">
            <div className="writer-panel__header">
              <div>
                <span className="writer-eyebrow">YOUR WORK</span>
                <h2>Recent stories</h2>
              </div>

              <Link to="/my-stories" className="writer-view-link">
                View all
                <ArrowRight size={14} />
              </Link>
            </div>

            <div className="writer-story-list">
              {recentStories.map((story) => (
                <div className="writer-story-row" key={story.id}>
                  <div className="writer-story-cover">
                    <BookOpen size={20} />
                    <span>{story.category}</span>
                  </div>

                  <div className="writer-story-info">
                    <div className="writer-story-title">
                      <h3>{story.title}</h3>

                      <span
                        className={`writer-status writer-status--${story.status.toLowerCase()}`}
                      >
                        {story.status}
                      </span>
                    </div>

                    <div className="writer-story-meta">
                      <span>
                        <Eye size={13} />
                        {story.views}
                      </span>

                      <span>
                        <Heart size={13} />
                        {story.likes}
                      </span>

                      <span>
                        <MessageCircle size={13} />
                        {story.comments}
                      </span>
                    </div>

                    <small>Updated {story.updated}</small>
                  </div>

                  <Link
                    to={`/stories/${story.id}`}
                    className="writer-story-arrow"
                    aria-label={`Open ${story.title}`}
                  >
                    <ArrowRight size={17} />
                  </Link>
                </div>
              ))}
            </div>
          </div>

          {/* Activity */}
          <div className="writer-panel writer-panel--activity">
            <div className="writer-panel__header">
              <div>
                <span className="writer-eyebrow">RECENT</span>
                <h2>Activity</h2>
              </div>

              <MoreHorizontal size={20} className="activity-more" />
            </div>

            <div className="writer-activity-list">
              {activity.map((item, index) => (
                <div className="writer-activity-item" key={index}>
                  <div className="writer-activity-dot" />

                  <div>
                    <strong>{item.title}</strong>
                    <p>{item.text}</p>
                    <span>{item.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Performance */}
        <section className="writer-performance">
          <div className="writer-performance__header">
            <div>
              <span className="writer-eyebrow">PERFORMANCE</span>
              <h2>Story performance</h2>
              <p>Your stories reached more readers this month.</p>
            </div>

            <span className="writer-growth">
              <TrendingUp size={15} />
              +18.6%
            </span>
          </div>

          <div className="writer-chart">
            <div className="writer-chart__labels">
              <span>100K</span>
              <span>75K</span>
              <span>50K</span>
              <span>25K</span>
              <span>0</span>
            </div>

            <div className="writer-chart__area">
              <div className="writer-chart__line writer-chart__line--1" />
              <div className="writer-chart__line writer-chart__line--2" />
              <div className="writer-chart__line writer-chart__line--3" />
              <div className="writer-chart__line writer-chart__line--4" />

              <svg
                className="writer-chart__svg"
                viewBox="0 0 700 220"
                preserveAspectRatio="none"
                aria-hidden="true"
              >
               <path
  d="M0 185 C65 175 80 165 125 170 C170 175 180 145 225 150 C270 155 285 115 330 125 C375 135 390 105 435 112 C480 120 500 80 545 88 C590 96 625 52 700 60"
  fill="none"
  stroke="currentColor"
  strokeWidth="3"
/>

                <path
  d="M0 185 C65 175 80 165 125 170 C170 175 180 145 225 150 C270 155 285 115 330 125 C375 135 390 105 435 112 C480 120 500 80 545 88 C590 96 625 52 700 60 L700 220 L0 220 Z"
  fill="currentColor"
  opacity="0.06"
  stroke="none"
/>
              </svg>

              <div className="writer-chart__months">
                <span>Mar</span>
                <span>Apr</span>
                <span>May</span>
                <span>Jun</span>
                <span>Jul</span>
                <span>Aug</span>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="writer-dashboard-cta">
          <div className="writer-dashboard-cta__icon">
            <Edit3 size={22} />
          </div>

          <span className="writer-eyebrow">KEEP CREATING</span>

          <h2>Have another story in you?</h2>

          <p>
            Start writing something new and share your next world with
            Lumora readers.
          </p>

          <Link to="/create-story" className="writer-primary-btn">
            <Plus size={17} />
            Start Writing
          </Link>
        </section>
      </main>
    </div>
  );
}

export default Dashboard;
