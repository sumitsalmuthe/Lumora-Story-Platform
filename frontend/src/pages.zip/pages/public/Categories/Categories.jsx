import { Link } from "react-router-dom";
import {
  FaArrowRight,
  FaBook,
  FaFeather,
  FaGhost,
  FaHeart,
  FaMask,
  FaRocket,
  FaWandMagicSparkles,
  FaBolt,
} from "react-icons/fa6";

import Footer from "../../../components/layout/Footer/Footer";

import "./Categories.css";

const popularGenres = [
  {
    name: "Fantasy",
    description: "Enter worlds where anything is possible.",
    label: "Most explored",
    path: "/categories/fantasy",
    icon: FaWandMagicSparkles,
  },
  {
    name: "Horror",
    description: "For stories that stay with you after midnight.",
    label: "Readers' favorite",
    path: "/categories/horror",
    icon: FaGhost,
  },
  {
    name: "Romance",
    description: "Love stories worth getting lost in.",
    label: "Popular",
    path: "/categories/romance",
    icon: FaHeart,
  },
];

const allGenres = [
  {
    name: "Fantasy",
    description: "Magic, kingdoms, mythical worlds and impossible adventures.",
    stories: "1.2K stories",
    path: "/categories/fantasy",
    icon: FaWandMagicSparkles,
  },
  {
    name: "Romance",
    description: "Love, relationships, emotions and unforgettable connections.",
    stories: "980 stories",
    path: "/categories/romance",
    icon: FaHeart,
  },
  {
    name: "Horror",
    description: "Dark places, terrifying secrets and stories that haunt you.",
    stories: "760 stories",
    path: "/categories/horror",
    icon: FaGhost,
  },
  {
    name: "Mystery",
    description: "Secrets, clues, investigations and unexpected answers.",
    stories: "640 stories",
    path: "/categories/mystery",
    icon: FaMask,
  },
  {
    name: "Sci-Fi",
    description: "Space, technology, distant worlds and the future.",
    stories: "520 stories",
    path: "/categories/sci-fi",
    icon: FaRocket,
  },
  {
    name: "Thriller",
    description: "Suspense, danger, twists and stories that keep you guessing.",
    stories: "470 stories",
    path: "/categories/thriller",
    icon: FaBolt,
  },
  {
    name: "Fiction",
    description: "Original worlds, unforgettable characters and endless possibilities.",
    stories: "1.8K stories",
    path: "/categories/fiction",
    icon: FaBook,
  },
  {
    name: "Poetry",
    description: "Words, emotions and thoughts expressed through poetry.",
    stories: "390 stories",
    path: "/categories/poetry",
    icon: FaFeather,
  },
  {
    name: "Nonfiction",
    description: "Real experiences, ideas, knowledge and stories from life.",
    stories: "280 stories",
    path: "/categories/nonfiction",
    icon: FaFeather,
  },
];

function Categories() {
  return (
    <div className="lumora-categories">
      {/* =====================================================
          HERO
      ===================================================== */}

      <section className="lumora-categories__hero">
        <div className="lumora-categories__container">
          <span className="lumora-categories__eyebrow">
            EXPLORE LUMORA
          </span>

          <h1>
            Find a world
            <span> worth getting lost in.</span>
          </h1>

          <p>
            Explore stories by genre and discover the worlds,
            characters and ideas waiting for you.
          </p>
        </div>
      </section>

      {/* =====================================================
          POPULAR GENRES
      ===================================================== */}

      <section className="lumora-categories__popular">
        <div className="lumora-categories__container">
          <div className="lumora-categories__section-header">
            <div>
              <span className="lumora-categories__section-eyebrow">
                START HERE
              </span>

              <h2>Popular genres</h2>

              <p>
                Some of the worlds Lumora readers are exploring
                right now.
              </p>
            </div>
          </div>

          <div className="lumora-categories__popular-grid">
            {popularGenres.map((genre) => {
              const Icon = genre.icon;

              return (
                <Link
                  key={genre.name}
                  to={genre.path}
                  className="lumora-categories__popular-card"
                >
                  <div className="lumora-categories__icon">
                    <Icon size={17} />
                  </div>

                  <span className="lumora-categories__card-label">
                    {genre.label}
                  </span>

                  <h3>{genre.name}</h3>

                  <p>{genre.description}</p>

                  <span className="lumora-categories__explore">
                    Explore genre
                    <FaArrowRight size={9} />
                  </span>

                  <div className="lumora-categories__circle" />
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* =====================================================
          ALL GENRES
      ===================================================== */}

      <section className="lumora-categories__all">
        <div className="lumora-categories__container">
          <div className="lumora-categories__section-header lumora-categories__section-header--all">
            <div>
              <span className="lumora-categories__section-eyebrow">
                ALL GENRES
              </span>

              <h2>Explore by genre</h2>

              <p>
                Choose a genre and find your next story.
              </p>
            </div>

            <span className="lumora-categories__genre-count">
              {allGenres.length} genres
            </span>
          </div>

          <div className="lumora-categories__grid">
            {allGenres.map((genre) => {
              const Icon = genre.icon;

              return (
                <Link
                  key={genre.name}
                  to={genre.path}
                  className="lumora-categories__genre-card"
                >
                  <div className="lumora-categories__genre-icon">
                    <Icon size={15} />
                  </div>

                  <div className="lumora-categories__genre-content">
                    <h3>{genre.name}</h3>

                    <p>{genre.description}</p>

                    <span>{genre.stories}</span>
                  </div>

                  <FaArrowRight
                    className="lumora-categories__genre-arrow"
                    size={10}
                  />
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* =====================================================
          WRITER CTA
      ===================================================== */}

      <section className="lumora-categories__writer">
        <div className="lumora-categories__container">
          <div className="lumora-categories__writer-box">
            <div className="lumora-categories__writer-icon">
              <FaFeather size={16} />
            </div>

            <span>FOR WRITERS</span>

            <h2>Don't see your story yet?</h2>

            <p>
              Create it yourself. Share your world with readers
              on Lumora.
            </p>

            <Link to="/become-writer">
              Start Writing
              <FaArrowRight size={10} />
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

export default Categories;