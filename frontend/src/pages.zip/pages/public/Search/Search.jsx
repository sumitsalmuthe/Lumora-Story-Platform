import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";

import {
  Search as SearchIcon,
  Clock3,
  TrendingUp,
  Users,
  ArrowRight,
  X,
} from "lucide-react";

import Navbar from "../../../components/layout/Navbar/Navbar";
import Footer from "../../../components/layout/Footer/Footer";

import "./Search.css";

const trendingStories = [
  {
    id: "trending-1",
    title: "Under a Dead Sky",
    author: "Aarav Mehta",
    genre: "Horror",
  },
  {
    id: "trending-2",
    title: "The Last Signal",
    author: "Mira Sen",
    genre: "Sci-Fi",
  },
  {
    id: "trending-3",
    title: "Where Shadows Sleep",
    author: "Riya Kapoor",
    genre: "Fantasy",
  },
  {
    id: "trending-4",
    title: "Letters Never Sent",
    author: "Kabir Rao",
    genre: "Romance",
  },
];

const popularAuthors = [
  {
    id: "writer-1",
    name: "Aarav Mehta",
    stories: 12,
    followers: "18.4K",
  },
  {
    id: "writer-2",
    name: "Mira Sen",
    stories: 8,
    followers: "12.7K",
  },
  {
    id: "writer-3",
    name: "Riya Kapoor",
    stories: 16,
    followers: "10.2K",
  },
  {
    id: "writer-4",
    name: "Kabir Rao",
    stories: 9,
    followers: "8.9K",
  },
];

function Search() {
  const [searchParams, setSearchParams] = useSearchParams();

  const initialQuery = searchParams.get("q") || "";

  const [query, setQuery] = useState(initialQuery);

const [recentSearches, setRecentSearches] = useState([
  "Fantasy",
  "Under a Dead Sky",
  "Aarav Mehta",
]);

/* =========================================================
   NORMALIZED SEARCH QUERY
========================================================= */

const normalizedQuery = query.trim().toLowerCase();
  /* =========================================================
     FILTER STORIES
  ========================================================= */

  const filteredStories = normalizedQuery
    ? trendingStories.filter(
        (story) =>
          story.title.toLowerCase().includes(normalizedQuery) ||
          story.author.toLowerCase().includes(normalizedQuery) ||
          story.genre.toLowerCase().includes(normalizedQuery)
      )
    : [];

  /* =========================================================
     FILTER AUTHORS
  ========================================================= */

  const filteredAuthors = normalizedQuery
    ? popularAuthors.filter((author) =>
        author.name.toLowerCase().includes(normalizedQuery)
      )
    : [];

  /* =========================================================
     SEARCH SUBMIT
  ========================================================= */

  const handleSearch = (event) => {
    event.preventDefault();

    const value = query.trim();

    if (!value) {
      setSearchParams({});
      return;
    }

    setRecentSearches((current) => [
      value,
      ...current.filter(
        (item) =>
          item.toLowerCase() !== value.toLowerCase()
      ),
    ].slice(0, 5));

    setSearchParams({ q: value });
  };

  /* =========================================================
     REMOVE RECENT SEARCH
  ========================================================= */

  const removeRecentSearch = (value) => {
    setRecentSearches((current) =>
      current.filter((item) => item !== value)
    );
  };

  /* =========================================================
     CLEAR SEARCH
  ========================================================= */

  const handleClearSearch = () => {
    setQuery("");
    setSearchParams({});
  };

  /* =========================================================
     SELECT RECENT SEARCH
  ========================================================= */

  const handleRecentSearch = (item) => {
    setQuery(item);
    setSearchParams({ q: item });
  };

  return (
    <div className="lumora-search-page">
      <Navbar />

      <main className="lumora-search-page__main">
        <div className="lumora-search-page__container">

          {/* =================================================
              HEADER
          ================================================= */}

          <header className="lumora-search-page__header">
            <span className="lumora-search-page__eyebrow">
              DISCOVER LUMORA
            </span>

            <h1>Search stories and writers.</h1>

            <p>
              Find stories, authors and genres that match what you
              want to read.
            </p>
          </header>

          {/* =================================================
              SEARCH BAR
          ================================================= */}

          <form
            className="lumora-search-page__search"
            onSubmit={handleSearch}
          >
            <SearchIcon
              size={20}
              strokeWidth={1.8}
              className="lumora-search-page__search-icon"
            />

            <input
              type="search"
              value={query}
              onChange={(event) =>
                setQuery(event.target.value)
              }
              placeholder="Search stories, writers, genres..."
              aria-label="Search Lumora"
            />

            {query && (
              <button
                type="button"
                className="lumora-search-page__clear"
                onClick={handleClearSearch}
                aria-label="Clear search"
              >
                <X size={17} />
              </button>
            )}

            <button
              type="submit"
              className="lumora-search-page__submit"
            >
              Search
            </button>
          </form>

          {/* =================================================
              SEARCH RESULTS
          ================================================= */}

          {normalizedQuery ? (
            <section className="lumora-search-page__results">

              <div className="lumora-search-page__section-heading">
                <div>
                  <span>SEARCH RESULTS</span>

                  <h2>
                    Results for "{query}"
                  </h2>
                </div>
              </div>

              {/* ================= STORIES ================= */}

              {filteredStories.length > 0 && (
                <div className="lumora-search-page__result-group">

                  <div className="lumora-search-page__group-title">
                    <TrendingUp size={16} />

                    <span>Stories</span>
                  </div>

                  <div className="lumora-search-page__story-list">

                    {filteredStories.map((story) => (
                      <Link
                        key={story.id}
                        to={`/stories/${story.id}`}
                        className="lumora-search-page__story"
                      >
                        <div className="lumora-search-page__story-cover">
                          <span>
                            {story.title.charAt(0)}
                          </span>
                        </div>

                        <div className="lumora-search-page__story-content">
                          <h3>{story.title}</h3>

                          <p>{story.author}</p>

                          <span>{story.genre}</span>
                        </div>

                        <ArrowRight size={16} />
                      </Link>
                    ))}

                  </div>
                </div>
              )}

              {/* ================= AUTHORS ================= */}

              {filteredAuthors.length > 0 && (
                <div className="lumora-search-page__result-group">

                  <div className="lumora-search-page__group-title">
                    <Users size={16} />

                    <span>Authors</span>
                  </div>

                  <div className="lumora-search-page__author-list">

                    {filteredAuthors.map((author) => (
                      <Link
                        key={author.id}
                        to={`/profile/${author.id}`}
                        className="lumora-search-page__author"
                      >
                        <div className="lumora-search-page__author-avatar">
                          {author.name
                            .split(" ")
                            .map((part) => part[0])
                            .join("")
                            .slice(0, 2)}
                        </div>

                        <div>
                          <h3>{author.name}</h3>

                          <p>
                            {author.stories} stories ·{" "}
                            {author.followers} followers
                          </p>
                        </div>

                        <ArrowRight size={16} />
                      </Link>
                    ))}

                  </div>
                </div>
              )}

              {/* ================= NO RESULTS ================= */}

              {!filteredStories.length &&
                !filteredAuthors.length && (
                  <div className="lumora-search-page__empty">

                    <SearchIcon size={24} />

                    <h3>No results found</h3>

                    <p>
                      Try searching for another story, writer or
                      genre.
                    </p>

                  </div>
                )}

            </section>
          ) : (

            /* =================================================
               DISCOVERY STATE
            ================================================= */

            <div className="lumora-search-page__discovery">

              {/* =================================================
                  RECENT SEARCHES
              ================================================= */}

              <section className="lumora-search-page__block">

                <div className="lumora-search-page__section-heading">
                  <div>
                    <span>YOUR SEARCHES</span>

                    <h2>Recent Searches</h2>
                  </div>
                </div>

                {recentSearches.length > 0 ? (

                  <div className="lumora-search-page__recent">

                    {recentSearches.map((item) => (
                      <button
                        key={item}
                        type="button"
                        className="lumora-search-page__recent-item"
                        onClick={() =>
                          handleRecentSearch(item)
                        }
                      >
                        <Clock3 size={15} />

                        <span>{item}</span>

                        <X
                          size={14}
                          onClick={(event) => {
                            event.stopPropagation();

                            removeRecentSearch(item);
                          }}
                        />
                      </button>
                    ))}

                  </div>

                ) : (

                  <p className="lumora-search-page__muted">
                    Your recent searches will appear here.
                  </p>

                )}

              </section>

              {/* =================================================
                  TRENDING STORIES
              ================================================= */}

              <section className="lumora-search-page__block">

                <div className="lumora-search-page__section-heading">

                  <div>
                    <span>
                      WHAT READERS ARE READING
                    </span>

                    <h2>Trending Stories</h2>
                  </div>

                  <Link to="/popular">
                    View all
                    <ArrowRight size={14} />
                  </Link>

                </div>

                <div className="lumora-search-page__story-list">

                  {trendingStories.map((story) => (
                    <Link
                      key={story.id}
                      to={`/stories/${story.id}`}
                      className="lumora-search-page__story"
                    >
                      <div className="lumora-search-page__story-cover">
                        <span>
                          {story.title.charAt(0)}
                        </span>
                      </div>

                      <div className="lumora-search-page__story-content">
                        <h3>{story.title}</h3>

                        <p>{story.author}</p>

                        <span>{story.genre}</span>
                      </div>

                      <ArrowRight size={16} />
                    </Link>
                  ))}

                </div>

              </section>

              {/* =================================================
                  POPULAR AUTHORS
              ================================================= */}

              <section className="lumora-search-page__block">

                <div className="lumora-search-page__section-heading">

                  <div>
                    <span>
                      COMMUNITY FAVOURITES
                    </span>

                    <h2>Popular Authors</h2>
                  </div>

                  <Link to="/community">
                    View all
                    <ArrowRight size={14} />
                  </Link>

                </div>

                <div className="lumora-search-page__author-list">

                  {popularAuthors.map((author) => (
                    <Link
                      key={author.id}
                      to={`/profile/${author.id}`}
                      className="lumora-search-page__author"
                    >
                      <div className="lumora-search-page__author-avatar">
                        {author.name
                          .split(" ")
                          .map((part) => part[0])
                          .join("")
                          .slice(0, 2)}
                      </div>

                      <div>
                        <h3>{author.name}</h3>

                        <p>
                          {author.stories} stories ·{" "}
                          {author.followers} followers
                        </p>
                      </div>

                      <ArrowRight size={16} />
                    </Link>
                  ))}

                </div>

              </section>

            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default Search;
