
import { Link, useParams } from "react-router-dom";
import {
  FaArrowRight,
  FaBookOpen,
  FaFilter,
  FaHeart,
  FaBookmark,
} from "react-icons/fa6";

import Footer from "../../../components/layout/Footer/Footer";

import "./GenreStories.css";

const genreConfig = {
  fantasy: {
    name: "Fantasy",
    description:
      "Magic, kingdoms, mythical worlds and impossible adventures.",
    intro:
      "Step into worlds where magic is real, kingdoms rise and fall, and anything is possible.",
    related: ["Adventure", "Paranormal", "Mystery", "Drama"],
  },

  romance: {
    name: "Romance",
    description:
      "Love, relationships, emotions and unforgettable connections.",
    intro:
      "Discover stories about love, relationships, heartbreak and the connections that change everything.",
    related: ["Drama", "Comedy", "Coming of Age", "LGBTQ"],
  },

  mystery: {
    name: "Mystery",
    description:
      "Secrets, clues, investigations and unexpected answers.",
    intro:
      "Follow hidden clues, uncover secrets and discover stories where nothing is quite what it seems.",
    related: ["Crime", "Thriller", "Horror", "Paranormal"],
  },

  horror: {
    name: "Horror",
    description:
      "Dark places, terrifying secrets and stories that haunt you.",
    intro:
      "Enter unsettling worlds filled with fear, darkness, supernatural mysteries and things best left unknown.",
    related: ["Paranormal", "Mystery", "Thriller", "Dystopian"],
  },

  thriller: {
    name: "Thriller",
    description:
      "Suspense, danger, twists and stories that keep you guessing.",
    intro:
      "Stay on the edge of your seat with dangerous choices, unexpected twists and relentless suspense.",
    related: ["Mystery", "Crime", "Horror", "Adventure"],
  },

  "sci-fi": {
    name: "Sci-Fi",
    description:
      "Space, technology, distant worlds and the future.",
    intro:
      "Explore distant planets, advanced technology, alternate futures and worlds beyond imagination.",
    related: ["Dystopian", "Adventure", "Mystery", "Thriller"],
  },

  adventure: {
    name: "Adventure",
    description:
      "Journeys, discoveries, danger and unforgettable adventures.",
    intro:
      "Follow characters across unknown lands, dangerous journeys and worlds waiting to be discovered.",
    related: ["Fantasy", "Sci-Fi", "Thriller", "Historical"],
  },

  drama: {
    name: "Drama",
    description:
      "Emotional stories about people, choices and life-changing moments.",
    intro:
      "Experience powerful characters, difficult choices, relationships and moments that stay with you.",
    related: ["Romance", "Coming of Age", "Crime", "LGBTQ"],
  },

  crime: {
    name: "Crime",
    description:
      "Criminal minds, investigations, secrets and dangerous choices.",
    intro:
      "Enter stories of investigations, criminals, conspiracies and the pursuit of truth.",
    related: ["Mystery", "Thriller", "Drama", "Historical"],
  },

  historical: {
    name: "Historical",
    description:
      "Stories inspired by people, places and moments from history.",
    intro:
      "Travel through different eras and experience stories shaped by history, culture and changing worlds.",
    related: ["Drama", "Adventure", "Romance", "Crime"],
  },

  action: {
  name: "Action",
  description:
    "Fast-paced stories filled with danger, conflict, battles and unforgettable heroes.",
  intro:
    "Enter worlds of high-stakes missions, powerful characters, dangerous enemies and battles where every decision matters.",
  related: ["Adventure", "Thriller", "Crime", "Fantasy"],
},

supernatural: {
  name: "Supernatural",
  description:
    "Strange powers, mysterious forces and worlds beyond the ordinary.",
  intro:
    "Discover stories where supernatural forces, mysterious abilities and unexplained events become part of everyday life.",
  related: ["Paranormal", "Horror", "Fantasy", "Mystery"],
},

psychological: {
  name: "Psychological",
  description:
    "Stories exploring the mind, emotions, secrets and human behavior.",
  intro:
    "Explore stories filled with complex minds, emotional struggles, hidden motives and unexpected twists.",
  related: ["Mystery", "Thriller", "Drama", "Horror"],
},

  poetry: {
    name: "Poetry",
    description:
      "Words, emotions and ideas expressed through poetry.",
    intro:
      "Discover poems that turn emotions, memories, ideas and experiences into words.",
    related: ["Romance", "Drama", "Coming of Age", "LGBTQ"],
  },

  nonfiction: {
    name: "Nonfiction",
    description:
      "Real experiences, ideas, knowledge and stories from life.",
    intro:
      "Read real experiences, personal journeys, knowledge and perspectives from the world around us.",
    related: ["Historical", "Drama", "Short Stories", "Coming of Age"],
  },

  fanfiction: {
    name: "Fanfiction",
    description:
      "New stories inspired by worlds, characters and fandoms you love.",
    intro:
      "Explore new adventures, alternate stories and fresh interpretations of familiar worlds and characters.",
    related: ["Fantasy", "Romance", "Adventure", "Sci-Fi"],
  },

  "young-adult": {
    name: "Young Adult",
    description:
      "Stories about growing up, identity, friendship and finding your place.",
    intro:
      "Discover stories about identity, friendship, relationships, growing up and the challenges of becoming yourself.",
    related: ["Coming of Age", "Romance", "Drama", "Fantasy"],
  },

  comedy: {
    name: "Comedy",
    description:
      "Funny stories, memorable characters and moments that make you laugh.",
    intro:
      "Take a break and discover stories filled with humor, chaos, friendship and unforgettable characters.",
    related: ["Romance", "Drama", "Short Stories", "Young Adult"],
  },

  "short-stories": {
    name: "Short Stories",
    description:
      "Complete stories that take you somewhere in just a few pages.",
    intro:
      "Find powerful ideas, memorable characters and complete stories you can enjoy in one sitting.",
    related: ["Poetry", "Drama", "Horror", "Comedy"],
  },

  paranormal: {
    name: "Paranormal",
    description:
      "Supernatural mysteries, unexplained events and strange encounters.",
    intro:
      "Discover stories where the unexplained becomes real and the supernatural waits just beyond the ordinary.",
    related: ["Horror", "Mystery", "Fantasy", "Thriller"],
  },

  dystopian: {
    name: "Dystopian",
    description:
      "Broken societies, controlled futures and worlds on the edge.",
    intro:
      "Explore imagined futures shaped by control, rebellion, survival and societies that have lost their way.",
    related: ["Sci-Fi", "Thriller", "Adventure", "Drama"],
  },

  "coming-of-age": {
    name: "Coming of Age",
    description:
      "Stories about growing up, identity, change and discovering yourself.",
    intro:
      "Follow characters through friendship, change, first experiences and the journey toward discovering who they are.",
    related: ["Young Adult", "Romance", "Drama", "LGBTQ"],
  },

  lgbtq: {
    name: "LGBTQ",
    description:
      "Stories about identity, love, relationships and authentic experiences.",
    intro:
      "Discover stories about identity, relationships, self-discovery, love and finding the courage to be yourself.",
    related: ["Romance", "Drama", "Coming of Age", "Young Adult"],
  },
};

const mockStories = [
  {
    id: "genre-story-1",
    title: "The Last Kingdom",
    author: "Dev Malhotra",
    category: "Fantasy",
    description:
      "A fallen prince returns to a kingdom that no longer remembers his name.",
    views: "245K",
    likes: "18.2K",
    bookmarks: "9.4K",
  },
  {
    id: "genre-story-2",
    title: "Under a Dead Sky",
    author: "Aarav Mehta",
    category: "Horror",
    description:
      "The world ended quietly. What came after did not.",
    views: "198K",
    likes: "15.4K",
    bookmarks: "8.2K",
  },
  {
    id: "genre-story-3",
    title: "Letters Never Sent",
    author: "Kabir Rao",
    category: "Romance",
    description:
      "Some stories begin with words that were never meant to be read.",
    views: "112K",
    likes: "8.6K",
    bookmarks: "4.8K",
  },
  {
    id: "genre-story-4",
    title: "The Silent Room",
    author: "Naina Kapoor",
    category: "Mystery",
    description:
      "Every house has a secret. This one has a room no one is allowed to enter.",
    views: "176K",
    likes: "12.8K",
    bookmarks: "7.1K",
  },
  {
    id: "genre-story-5",
    title: "Beyond the Stars",
    author: "Mira Sen",
    category: "Sci-Fi",
    description:
      "Humanity's first journey beyond the solar system changes everything.",
    views: "154K",
    likes: "11.6K",
    bookmarks: "6.3K",
  },
  {
    id: "genre-story-6",
    title: "Seven Minutes to Dawn",
    author: "Rahul Shah",
    category: "Thriller",
    description:
      "Seven minutes remain before everything changes forever.",
    views: "86K",
    likes: "6.9K",
    bookmarks: "3.7K",
  },
];

const filters = ["All", "Latest", "Popular", "Most Read"];

function GenreStories() {
  const { genre } = useParams();

  const normalizedGenre = genre?.toLowerCase();

  const currentGenre =
    genreConfig[normalizedGenre] || {
      name: "Stories",
      description: "Explore stories on Lumora.",
      intro:
        "Discover stories, writers and worlds waiting to be explored.",
      related: ["Fantasy", "Romance", "Mystery", "Adventure"],
    };

  return (
    <div className="lumora-genre-page">
      {/* HERO */}
      <section className="lumora-genre-page__hero">
        <div className="lumora-genre-page__container">
          <span className="lumora-genre-page__eyebrow">
            EXPLORE GENRE
          </span>

          <h1>{currentGenre.name}</h1>

          <p className="lumora-genre-page__description">
            {currentGenre.description}
          </p>

          <p className="lumora-genre-page__intro">
            {currentGenre.intro}
          </p>
        </div>
      </section>

      {/* STORIES */}
      <section className="lumora-genre-page__stories">
        <div className="lumora-genre-page__container">
          <div className="lumora-genre-page__section-header">
            <div>
              <span>DISCOVER</span>

              <h2>
                {currentGenre.name} stories
              </h2>

              <p>
                Stories readers are exploring in this genre.
              </p>
            </div>

            <span className="lumora-genre-page__count">
              {mockStories.length} stories
            </span>
          </div>

          {/* FILTERS */}
          <div className="lumora-genre-page__filters">
            <div className="lumora-genre-page__filter-label">
              <FaFilter size={11} />
              Sort stories
            </div>

            {filters.map((filter, index) => (
              <button
                key={filter}
                type="button"
                className={`lumora-genre-page__filter ${
                  index === 0
                    ? "lumora-genre-page__filter--active"
                    : ""
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          {/* GRID */}
          <div className="lumora-genre-page__grid">
            {mockStories.map((story) => (
              <article
                key={story.id}
                className="lumora-genre-page__card"
              >
                <Link
                  to={`/stories/${story.id}`}
                  className="lumora-genre-page__cover"
                >
                  <div className="lumora-genre-page__cover-content">
                    <span>{story.category}</span>

                    <FaBookOpen size={22} />

                    <strong>{story.title}</strong>
                  </div>
                </Link>

                <div className="lumora-genre-page__card-body">
                  <span className="lumora-genre-page__card-category">
                    {story.category}
                  </span>

                  <Link
                    to={`/stories/${story.id}`}
                    className="lumora-genre-page__card-title"
                  >
                    {story.title}
                  </Link>

                  <span className="lumora-genre-page__author">
                    by {story.author}
                  </span>

                  <p>{story.description}</p>

                  <div className="lumora-genre-page__stats">
                    <span>
                      <FaBookOpen size={10} />
                      {story.views}
                    </span>

                    <span>
                      <FaHeart size={10} />
                      {story.likes}
                    </span>

                    <span>
                      <FaBookmark size={10} />
                      {story.bookmarks}
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <button
            type="button"
            className="lumora-genre-page__load-more"
          >
            Load more stories
            <FaArrowRight size={11} />
          </button>
        </div>
      </section>

      {/* RELATED GENRES */}
      <section className="lumora-genre-page__related">
        <div className="lumora-genre-page__container">
          <div className="lumora-genre-page__section-header">
            <div>
              <span>KEEP EXPLORING</span>

              <h2>Related genres</h2>

              <p>
                You might find your next favorite story here.
              </p>
            </div>
          </div>

          <div className="lumora-genre-page__related-grid">
            {currentGenre.related.map((relatedGenre) => {
              const relatedSlug = relatedGenre
                .toLowerCase()
                .replace(/\s+/g, "-");

              return (
                <Link
                  key={relatedGenre}
                  to={`/categories/${relatedSlug}`}
                  className="lumora-genre-page__related-card"
                >
                  <span>{relatedGenre}</span>
                  <FaArrowRight size={11} />
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* WRITER CTA */}
      <section className="lumora-genre-page__cta">
        <div className="lumora-genre-page__container">
          <div className="lumora-genre-page__cta-box">
            <span>FOR WRITERS</span>

            <h2>Your story belongs here.</h2>

            <p>
              Have a story that fits this genre? Share it with
              readers on Lumora.
            </p>

            <Link to="/become-writer">
              Start Writing
              <FaArrowRight size={10} />
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

export default GenreStories;
