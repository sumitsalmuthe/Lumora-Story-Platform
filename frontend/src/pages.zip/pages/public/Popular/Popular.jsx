import { Link } from "react-router-dom";
import {
  FaArrowRight,
  FaBookOpen,
  FaFire,
  FaChartLine,
  FaBookmark,
  FaPenNib,
} from "react-icons/fa6";

import Footer from "../../../components/layout/Footer/Footer";

import "./Popular.css";

const popularStories = [
  {
    id: "popular-1",
    rank: 1,
    title: "The Last Kingdom",
    author: "Dev Malhotra",
    category: "Fantasy",
    description:
      "A fallen prince returns to a kingdom that no longer remembers his name.",
    views: "245K",
    likes: "18.2K",
    bookmarks: "9.4K",
  },
  {
    id: "popular-2",
    rank: 2,
    title: "Under a Dead Sky",
    author: "Aarav Mehta",
    category: "Horror",
    description:
      "The world ended quietly. What came after did not.",
    views: "198K",
    likes: "15.4K",
    bookmarks: "8.2K",
  },
  {
    id: "popular-3",
    rank: 3,
    title: "The Silent Room",
    author: "Naina Kapoor",
    category: "Mystery",
    description:
      "Every house has a secret. This one has a room no one is allowed to enter.",
    views: "176K",
    likes: "12.8K",
    bookmarks: "7.1K",
  },
  {
    id: "popular-4",
    rank: 4,
    title: "Beyond the Stars",
    author: "Mira Sen",
    category: "Sci-Fi",
    description:
      "Humanity's first journey beyond the solar system changes everything.",
    views: "154K",
    likes: "11.6K",
    bookmarks: "6.3K",
  },
  {
    id: "popular-5",
    rank: 5,
    title: "Where Shadows Sleep",
    author: "Riya Kapoor",
    category: "Fantasy",
    description:
      "A forgotten kingdom hides a secret that should never be awakened.",
    views: "128K",
    likes: "9.7K",
    bookmarks: "5.4K",
  },
  {
    id: "popular-6",
    rank: 6,
    title: "Letters Never Sent",
    author: "Kabir Rao",
    category: "Romance",
    description:
      "Some stories begin with words that were never meant to be read.",
    views: "112K",
    likes: "8.6K",
    bookmarks: "4.8K",
  },
  {
    id: "popular-7",
    rank: 7,
    title: "The Last Signal",
    author: "Mira Sen",
    category: "Sci-Fi",
    description:
      "A mysterious signal reaches Earth from somewhere beyond the stars.",
    views: "97K",
    likes: "7.4K",
    bookmarks: "4.1K",
  },
  {
    id: "popular-8",
    rank: 8,
    title: "Seven Minutes to Dawn",
    author: "Rahul Shah",
    category: "Thriller",
    description:
      "Seven minutes remain before everything changes forever.",
    views: "86K",
    likes: "6.9K",
    bookmarks: "3.7K",
  },
];

const risingStories = [
  {
    id: "rising-1",
    title: "The City After Midnight",
    author: "Arjun Verma",
    category: "Mystery",
    growth: "+84%",
  },
  {
    id: "rising-2",
    title: "A World Between Pages",
    author: "Ishita Roy",
    category: "Fantasy",
    growth: "+72%",
  },
  {
    id: "rising-3",
    title: "The Girl Who Remembered Tomorrow",
    author: "Anaya Singh",
    category: "Sci-Fi",
    growth: "+65%",
  },
];

const filters = [
  "All",
  "Fantasy",
  "Romance",
  "Horror",
  "Mystery",
  "Sci-Fi",
  "Thriller",
];

function Popular() {
  return (
    <>
      <main className="lumora-popular">
        {/* HERO */}
        <section className="lumora-popular__hero">
          <div className="lumora-popular__container">
            <span className="lumora-popular__eyebrow">
              LUMORA POPULAR
            </span>

            <h1>
              Stories everyone
              <br />
              <span>is reading.</span>
            </h1>

            <p>
              Discover the stories readers are loving, sharing and
              coming back to again and again.
            </p>
          </div>
        </section>

        {/* FILTERS */}
        <section className="lumora-popular__filters">
          <div className="lumora-popular__container">
            <div className="lumora-popular__filter-header">
              <div>
                <span>DISCOVER</span>
                <h2>Popular stories</h2>
              </div>

              <div className="lumora-popular__period">
                <FaFire size={12} />
                This week
              </div>
            </div>

            <div className="lumora-popular__filter-list">
              {filters.map((filter, index) => (
                <button
                  key={filter}
                  type="button"
                  className={
                    index === 0
                      ? "lumora-popular__filter lumora-popular__filter--active"
                      : "lumora-popular__filter"
                  }
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* RANKING */}
        <section className="lumora-popular__ranking">
          <div className="lumora-popular__container">
            <div className="lumora-popular__section-heading">
              <div>
                <span>TOP READS</span>
                <h2>What readers love</h2>
                <p>
                  The most-read stories on Lumora right now.
                </p>
              </div>

              <span className="lumora-popular__count">
                8 stories
              </span>
            </div>

            <div className="lumora-popular__stories">
              {popularStories.map((story) => (
                <article
                  key={story.id}
                  className="lumora-popular__story"
                >
                  <div className="lumora-popular__rank">
                    #{story.rank}
                  </div>

                  <div className="lumora-popular__cover">
                    <FaBookOpen size={20} />
                  </div>

                  <div className="lumora-popular__story-content">
                    <div className="lumora-popular__story-meta">
                      <span>{story.category}</span>
                      <small>Fiction</small>
                    </div>

                    <Link
                      to={`/stories/${story.id}`}
                      className="lumora-popular__story-title"
                    >
                      {story.title}
                    </Link>

                    <p className="lumora-popular__author">
                      by {story.author}
                    </p>

                    <p className="lumora-popular__description">
                      {story.description}
                    </p>

                    <div className="lumora-popular__stats">
                      <span>
                        <FaBookOpen size={10} />
                        {story.views}
                      </span>

                      <span>
                        ♥ {story.likes}
                      </span>

                      <span>
                        <FaBookmark size={9} />
                        {story.bookmarks}
                      </span>
                    </div>
                  </div>

                  <Link
                    to={`/stories/${story.id}`}
                    className="lumora-popular__read"
                    aria-label={`Read ${story.title}`}
                  >
                    <FaArrowRight size={12} />
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* RISING */}
        <section className="lumora-popular__rising">
          <div className="lumora-popular__container">
            <div className="lumora-popular__section-heading">
              <div>
                <span>RISING NOW</span>
                <h2>Stories gaining momentum</h2>
                <p>
                  New stories readers are discovering quickly.
                </p>
              </div>
            </div>

            <div className="lumora-popular__rising-grid">
              {risingStories.map((story) => (
                <Link
                  key={story.id}
                  to={`/stories/${story.id}`}
                  className="lumora-popular__rising-card"
                >
                  <div className="lumora-popular__rising-icon">
                    <FaChartLine size={17} />
                  </div>

                  <div>
                    <span>{story.category}</span>

                    <h3>{story.title}</h3>

                    <p>by {story.author}</p>
                  </div>

                  <strong>{story.growth}</strong>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* WRITER CTA */}
        <section className="lumora-popular__writer">
          <div className="lumora-popular__container">
            <div className="lumora-popular__writer-box">
              <FaPenNib size={18} />

              <span>YOUR STORY COULD BE NEXT</span>

              <h2>Ready to share your world?</h2>

              <p>
                Write your story, publish it on Lumora and find
                readers who are waiting for something new.
              </p>

              <Link to="/become-writer">
                Start Writing →
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default Popular;
