import { Link } from "react-router-dom";
import {
  FaArrowRight,
  FaBookOpen,
  FaChartLine,
  FaFire,
  FaHeart,
  FaComments,
  FaClock,
  FaBolt,
  FaUserGroup,
} from "react-icons/fa6";

import Footer from "../../../components/layout/Footer/Footer";

import "./Trending.css";

const trendingSections = [
  {
    slug: "now",
    title: "Trending Now",
    description: "Stories readers are discovering right now.",
    icon: FaFire,
    metric: "Live momentum",
  },
  {
    slug: "rising",
    title: "Rising Stories",
    description: "Stories gaining attention faster than ever.",
    icon: FaChartLine,
    metric: "Growing fast",
  },
  {
    slug: "most-read",
    title: "Most Read",
    description: "The stories with the highest readership.",
    icon: FaBookOpen,
    metric: "By reads",
  },
  {
    slug: "most-liked",
    title: "Most Liked",
    description: "Stories readers are showing the most love.",
    icon: FaHeart,
    metric: "By likes",
  },
  {
    slug: "most-discussed",
    title: "Most Discussed",
    description: "Stories creating the biggest conversations.",
    icon: FaComments,
    metric: "By comments",
  },
  {
    slug: "this-week",
    title: "Popular This Week",
    description: "The stories dominating this week's reading.",
    icon: FaClock,
    metric: "This week",
  },
  {
    slug: "new",
    title: "New & Trending",
    description: "Fresh stories already catching readers' attention.",
    icon: FaBolt,
    metric: "Recently discovered",
  },
  {
    slug: "fastest-growing",
    title: "Fastest Growing",
    description: "Stories with the strongest recent momentum.",
    icon: FaChartLine,
    metric: "Fast growth",
  },
  {
    slug: "genres",
    title: "Trending by Genre",
    description: "See what is trending across every genre.",
    icon: FaBookOpen,
    metric: "Explore genres",
  },
  {
    slug: "writers",
    title: "Trending Writers",
    description: "Writers readers are discovering and following.",
    icon: FaUserGroup,
    metric: "Popular writers",
  },
];

const featuredStories = [
  {
    id: "trend-1",
    rank: 1,
    title: "Under a Dead Sky",
    author: "Aarav Mehta",
    category: "Horror",
    description:
      "When the world falls silent, survival becomes the only rule.",
    views: "92.4K",
    likes: "5.8K",
    comments: "1.9K",
    growth: "+84%",
  },
  {
    id: "trend-2",
    rank: 2,
    title: "The Last Signal",
    author: "Mira Sen",
    category: "Sci-Fi",
    description:
      "A mysterious signal reaches Earth from somewhere beyond the stars.",
    views: "78.3K",
    likes: "4.6K",
    comments: "1.4K",
    growth: "+72%",
  },
  {
    id: "trend-3",
    rank: 3,
    title: "Where Shadows Sleep",
    author: "Riya Kapoor",
    category: "Fantasy",
    description:
      "A forgotten kingdom hides a secret that should never be awakened.",
    views: "64.1K",
    likes: "3.9K",
    comments: "1.2K",
    growth: "+65%",
  },
  {
    id: "trend-4",
    rank: 4,
    title: "Letters Never Sent",
    author: "Kabir Rao",
    category: "Romance",
    description:
      "Some stories begin with words that were never meant to be read.",
    views: "52.8K",
    likes: "3.5K",
    comments: "980",
    growth: "+58%",
  },
];

function Trending() {
  return (
    <>
      <main className="lumora-trending">
        {/* =====================================================
            HERO
        ===================================================== */}

        <section className="lumora-trending__hero">
          <div className="lumora-trending__container">
            <span className="lumora-trending__eyebrow">
              LUMORA TRENDING
            </span>

            <h1>
              Discover what
              <br />
              <span>everyone is reading.</span>
            </h1>

            <p>
              Explore the stories gaining attention, growing quickly,
              and creating conversations across Lumora.
            </p>
          </div>
        </section>

        {/* =====================================================
            TRENDING CATEGORIES
        ===================================================== */}

        <section className="lumora-trending__categories">
          <div className="lumora-trending__container">
            <div className="lumora-trending__section-header">
              <div>
                <span>EXPLORE TRENDING</span>

                <h2>What's happening on Lumora</h2>

                <p>
                  Find stories based on what readers are doing right now.
                </p>
              </div>

              <span className="lumora-trending__count">
                {trendingSections.length} sections
              </span>
            </div>

            <div className="lumora-trending__category-grid">
              {trendingSections.map((section) => {
                const Icon = section.icon;

                return (
                  <Link
                    key={section.slug}
                    to={`/trending/${section.slug}`}
                    className="lumora-trending__category-card"
                  >
                    <div className="lumora-trending__category-icon">
                      <Icon size={16} />
                    </div>

                    <div className="lumora-trending__category-content">
                      <span>{section.metric}</span>

                      <h3>{section.title}</h3>

                      <p>{section.description}</p>
                    </div>

                    <FaArrowRight
                      size={10}
                      className="lumora-trending__category-arrow"
                    />
                  </Link>
                );
              })}
            </div>
          </div>
        </section>

        {/* =====================================================
            TRENDING NOW
        ===================================================== */}

        <section className="lumora-trending__stories">
          <div className="lumora-trending__container">
            <div className="lumora-trending__section-header">
              <div>
                <span>RIGHT NOW</span>

                <h2>Trending stories</h2>

                <p>
                  The stories gaining the most attention at the moment.
                </p>
              </div>

              <Link
                to="/trending/now"
                className="lumora-trending__view-all"
              >
                View all
                <FaArrowRight size={10} />
              </Link>
            </div>

            <div className="lumora-trending__story-list">
              {featuredStories.map((story) => (
                <article
                  key={story.id}
                  className="lumora-trending__story"
                >
                  <div className="lumora-trending__rank">
                    #{story.rank}
                  </div>

                  <div className="lumora-trending__story-cover">
                    <FaBookOpen size={20} />
                  </div>

                  <div className="lumora-trending__story-content">
                    <span className="lumora-trending__story-category">
                      {story.category}
                    </span>

                    <Link
                      to={`/stories/${story.id}`}
                      className="lumora-trending__story-title"
                    >
                      {story.title}
                    </Link>

                    <span className="lumora-trending__story-author">
                      by {story.author}
                    </span>

                    <p>{story.description}</p>

                    <div className="lumora-trending__story-stats">
                      <span>
                        <FaBookOpen size={9} />
                        {story.views}
                      </span>

                      <span>
                        <FaHeart size={9} />
                        {story.likes}
                      </span>

                      <span>
                        <FaComments size={9} />
                        {story.comments}
                      </span>

                      <strong>{story.growth}</strong>
                    </div>
                  </div>

                  <Link
                    to={`/stories/${story.id}`}
                    className="lumora-trending__story-arrow"
                    aria-label={`Read ${story.title}`}
                  >
                    <FaArrowRight size={11} />
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* =====================================================
            WRITER CTA
        ===================================================== */}

        <section className="lumora-trending__writer">
          <div className="lumora-trending__container">
            <div className="lumora-trending__writer-box">
              <span>FOR WRITERS</span>

              <h2>
                Your story could be trending next.
              </h2>

              <p>
                Share your story with Lumora readers and start building
                your audience.
              </p>

              <Link to="/become-writer">
                Start Writing
                <FaArrowRight size={10} />
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

export default Trending;