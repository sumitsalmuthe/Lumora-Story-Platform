import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, Filter, Search } from "lucide-react";

import Navbar from "../../../components/layout/Navbar/Navbar";
import Footer from "../../../components/layout/Footer/Footer";
import StoryRow from "../../../components/story/StoryRow/StoryRow";

import "./Discover.css";

const categories = [
  "All",
  "Fantasy",
  "Romance",
  "Horror",
  "Mystery",
  "Sci-Fi",
  "Thriller",
  "Fiction",
];

const demoStories = [
  {
    id: "discover-1",
    title: "The Weight of Silence",
    author: {
      id: "writer-1",
      username: "Aarav Mehta",
    },
    category: "Fiction",
    storyType: "Fiction",
    shortDescription:
      "A story about secrets, choices, and the things we never say.",
    views: 12400,
    likes: 860,
    bookmarks: 320,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "discover-2",
    title: "Under a Dead Sky",
    author: {
      id: "writer-2",
      username: "Mira Sen",
    },
    category: "Horror",
    storyType: "Fiction",
    shortDescription:
      "When the world falls silent, survival becomes the only rule.",
    views: 92400,
    likes: 5840,
    bookmarks: 2310,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "discover-3",
    title: "Beyond the Stars",
    author: {
      id: "writer-3",
      username: "Riya Kapoor",
    },
    category: "Sci-Fi",
    storyType: "Fiction",
    shortDescription:
      "A journey beyond everything humanity thought it knew.",
    views: 10900,
    likes: 740,
    bookmarks: 290,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "discover-4",
    title: "Where Shadows Sleep",
    author: {
      id: "writer-4",
      username: "Kabir Rao",
    },
    category: "Fantasy",
    storyType: "Fiction",
    shortDescription:
      "A forgotten kingdom hides a secret that should never be awakened.",
    views: 8700,
    likes: 620,
    bookmarks: 250,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "discover-5",
    title: "Letters Never Sent",
    author: {
      id: "writer-5",
      username: "Naina Kapoor",
    },
    category: "Romance",
    storyType: "Fiction",
    shortDescription:
      "Some stories begin with words that were never meant to be read.",
    views: 7600,
    likes: 510,
    bookmarks: 210,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "discover-6",
    title: "The Silent Room",
    author: {
      id: "writer-6",
      username: "Arjun Verma",
    },
    category: "Mystery",
    storyType: "Fiction",
    shortDescription:
      "Every house has a secret. This one has a room no one enters.",
    views: 17600,
    likes: 1280,
    bookmarks: 710,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "discover-7",
    title: "Seven Minutes to Dawn",
    author: {
      id: "writer-7",
      username: "Rahul Shah",
    },
    category: "Thriller",
    storyType: "Fiction",
    shortDescription:
      "Seven minutes remain before everything changes forever.",
    views: 6100,
    likes: 490,
    bookmarks: 180,
    status: "Published",
    mature: false,
    coverImage: "",
  },
  {
    id: "discover-8",
    title: "The Last Kingdom",
    author: {
      id: "writer-8",
      username: "Dev Malhotra",
    },
    category: "Fantasy",
    storyType: "Fiction",
    shortDescription:
      "A fallen prince must return to a kingdom that no longer remembers him.",
    views: 245000,
    likes: 18200,
    bookmarks: 9400,
    status: "Published",
    mature: false,
    coverImage: "",
  },
];

function Discover() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredStories = useMemo(() => {
    const query = search.trim().toLowerCase();

    return demoStories.filter((story) => {
      const matchesCategory =
        activeCategory === "All" ||
        story.category === activeCategory;

      const matchesSearch =
        !query ||
        story.title.toLowerCase().includes(query) ||
        story.author.username.toLowerCase().includes(query) ||
        story.category.toLowerCase().includes(query);

      return matchesCategory && matchesSearch;
    });
  }, [search, activeCategory]);

  const popularStories = [...demoStories]
    .sort((a, b) => b.views - a.views)
    .slice(0, 4);

  const latestStories = [...demoStories].slice(0, 4);

  return (
    <div className="lumora-discover">
      <Navbar />

      <main className="lumora-discover__main">
        {/* Hero */}
        <section className="lumora-discover__hero">
          <div className="lumora-discover__container">
            <span className="lumora-discover__eyebrow">
              DISCOVER STORIES
            </span>

            <h1>
              Find your next
              <span> favorite story.</span>
            </h1>

            <p>
              Explore stories, discover new writers and find worlds
              worth getting lost in.
            </p>

            <div className="lumora-discover__search">
              <Search size={15} strokeWidth={1.8} />

              <input
                type="search"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search stories, writers or genres..."
                aria-label="Search stories"
              />
            </div>
          </div>
        </section>

        {/* Category filters */}
        <section className="lumora-discover__filters">
          <div className="lumora-discover__container">
            <div className="lumora-discover__filter-header">
              <div>
                <span className="lumora-discover__filter-label">
                  BROWSE BY GENRE
                </span>

                <h2>Explore stories</h2>
              </div>

              <Filter size={14} strokeWidth={1.8} />
            </div>

            <div className="lumora-discover__categories">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  className={
                    activeCategory === category
                      ? "lumora-discover__category lumora-discover__category--active"
                      : "lumora-discover__category"
                  }
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Popular */}
        <section className="lumora-discover__section">
          <div className="lumora-discover__container">
            <div className="lumora-discover__section-header">
              <div>
                <span>POPULAR</span>
                <h2>Stories readers love</h2>
              </div>

              <Link to="/popular">
                View all
                <ArrowRight size={10} strokeWidth={1.8} />
              </Link>
            </div>

            <StoryRow
              stories={popularStories}
              columns={4}
              showDescription={false}
              showStats
              showBookmark
            />
          </div>
        </section>

        {/* Latest */}
        <section className="lumora-discover__section lumora-discover__section--muted">
          <div className="lumora-discover__container">
            <div className="lumora-discover__section-header">
              <div>
                <span>NEW & FRESH</span>
                <h2>Latest stories</h2>
              </div>

              <Link to="/discover">
                Explore all
                <BookOpen size={22} strokeWidth={1.8} />
              </Link>
            </div>

            <StoryRow
              stories={latestStories}
              columns={4}
              showDescription={false}
              showStats
              showBookmark
            />
          </div>
        </section>

        {/* All stories */}
        <section className="lumora-discover__section">
          <div className="lumora-discover__container">
            <div className="lumora-discover__section-header">
              <div>
                <span>DISCOVER</span>
                <h2>
                  {activeCategory === "All"
                    ? "All stories"
                    : `${activeCategory} stories`}
                </h2>
              </div>

              <span className="lumora-discover__result-count">
                {filteredStories.length} stories
              </span>
            </div>

            {filteredStories.length > 0 ? (
              <StoryRow
                stories={filteredStories}
                columns={4}
                showDescription={false}
                showStats
                showBookmark
              />
            ) : (
              <div className="lumora-discover__empty">
                <BookOpen size={22} strokeWidth={1.8} />

                <h3>No stories found</h3>

                <p>
                  Try another search or choose a different genre.
                </p>

                <button
                  type="button"
                  onClick={() => {
                    setSearch("");
                    setActiveCategory("All");
                  }}
                >
                  Clear filters
                </button>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

export default Discover;