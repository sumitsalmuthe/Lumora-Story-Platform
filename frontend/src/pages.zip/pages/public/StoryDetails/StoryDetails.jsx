import { Link, useNavigate, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import {
  FaArrowLeft,
  FaArrowRight,
  FaBookmark,
  FaBookOpen,
  FaEye,
  FaHeart,
  FaRegBookmark,
  FaStar,
} from "react-icons/fa6";

import "./StoryDetails.css";
import storyService from "../../../services/stories/storyService";
import bookmarkService from "../../../services/bookmarks/bookmarkService";
import useAuth from "../../../context/AuthContext/useAuth";

const stories = {
  "the-last-kingdom": {
    title: "The Last Kingdom",
    subtitle: "A kingdom forgotten. A prince who refuses to stay forgotten.",
    author: "Dev Malhotra",
    authorId: "writer-5",
    category: "Fantasy",
    storyType: "Fiction",
    description:
      "A fallen prince returns to a kingdom that no longer remembers him. As old alliances collapse and a forgotten enemy rises, he must decide whether the throne is worth everything he has lost.",
    coverImage: "",
    views: "245K",
    likes: "18.2K",
    bookmarks: "9.4K",
    rating: "4.8",
    chapters: 24,
    status: "Completed",
    updated: "2 days ago",
    tags: ["Fantasy", "Kingdom", "Adventure", "Magic"],
  },
  "under-a-dead-sky": {
    title: "Under a Dead Sky",
    subtitle: "The world ended quietly. What came after did not.",
    author: "Aarav Mehta",
    authorId: "writer-1",
    category: "Horror",
    storyType: "Fiction",
    description:
      "The world ended without warning. Cities went silent, roads became empty, and something began moving through the darkness. Now a small group of survivors must find out what happened before the night finds them.",
    coverImage: "",
    views: "198K",
    likes: "15.4K",
    bookmarks: "8.2K",
    rating: "4.7",
    chapters: 31,
    status: "Ongoing",
    updated: "Today",
    tags: ["Horror", "Survival", "Apocalypse", "Thriller"],
  },
  "where-shadows-sleep": {
    title: "Where Shadows Sleep",
    subtitle: "Some kingdoms hide their secrets in the dark.",
    author: "Riya Kapoor",
    authorId: "writer-3",
    category: "Fantasy",
    storyType: "Fiction",
    description:
      "A forgotten kingdom hides a secret that should never be awakened. When a young traveller crosses its ancient borders, the shadows begin remembering things the kingdom tried to forget.",
    coverImage: "",
    views: "87K",
    likes: "7.2K",
    bookmarks: "5.4K",
    rating: "4.6",
    chapters: 18,
    status: "Ongoing",
    updated: "Yesterday",
    tags: ["Fantasy", "Magic", "Mystery", "Adventure"],
  },
};

const defaultStory = stories["the-last-kingdom"];

const chapterData = [
  {
    number: 1,
    title: "The Kingdom That Forgot",
    date: "Aug 10, 2026",
    views: "12.4K",
  },
  {
    number: 2,
    title: "A Stranger at the Gate",
    date: "Aug 10, 2026",
    views: "10.8K",
  },
  {
    number: 3,
    title: "The Old King's Secret",
    date: "Aug 11, 2026",
    views: "9.6K",
  },
  {
    number: 4,
    title: "Into the Forgotten Woods",
    date: "Aug 11, 2026",
    views: "8.9K",
  },
  {
    number: 5,
    title: "The Shadow Returns",
    date: "Aug 12, 2026",
    views: "8.2K",
  },
];

function StoryCover({ story }) {
  return (
    <div className="lumora-story-details__cover">
      {story.coverImage ? (
        <img src={story.coverImage} alt={story.title} />
      ) : (
        <div className="lumora-story-details__cover-placeholder">
          <FaBookOpen size={30} />
          <span>{story.category}</span>
        </div>
      )}
    </div>
  );
}

function StoryDetails() {
  const { storyId } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [story, setStory] = useState(stories[storyId] || defaultStory);
  const [chapters, setChapters] = useState(chapterData);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const isApiStory = /^[a-f\d]{24}$/i.test(storyId || "");

  useEffect(() => {
    if (!isApiStory) {
      return;
    }

    const loadStory = async () => {
      setIsLoading(true);
      setError("");

      try {
        const response = await storyService.getStoryById(storyId);
        const apiStory = response.story;
        setStory({
          ...apiStory,
          description: apiStory.shortDescription,
          chapters: response.chapters.length,
          author: apiStory.author?.username || "Unknown Writer",
          authorId: apiStory.author?._id,
          likes: apiStory.likes?.length || 0,
          updated: new Date(apiStory.updatedAt).toLocaleDateString(),
        });
        setChapters(response.chapters);

        if (isAuthenticated) {
          const [bookmarkResponse, likeResponse] = await Promise.all([
            bookmarkService.checkBookmark(storyId),
            storyService.checkLike(storyId),
          ]);
          setIsBookmarked(bookmarkResponse.bookmarked);
          setIsLiked(likeResponse.liked);
        }
      } catch (requestError) {
        setError(requestError.response?.data?.message || "Unable to load this story.");
      } finally {
        setIsLoading(false);
      }
    };

    loadStory();
  }, [isApiStory, isAuthenticated, storyId]);

  const requireLogin = () => {
    navigate("/login", { state: { from: { pathname: `/stories/${storyId}` } } });
  };

  const toggleBookmark = async () => {
    if (!isAuthenticated) {
      requireLogin();
      return;
    }

    try {
      if (isBookmarked) {
        await bookmarkService.removeBookmark(storyId);
      } else {
        await bookmarkService.addBookmark(storyId);
      }
      setIsBookmarked((current) => !current);
    } catch (requestError) {
      setError(requestError.response?.data?.message || "Unable to update bookmark.");
    }
  };

  const toggleLike = async () => {
    if (!isAuthenticated) {
      requireLogin();
      return;
    }

    try {
      const response = isLiked
        ? await storyService.removeLike(storyId)
        : await storyService.likeStory(storyId);
      setIsLiked((current) => !current);
      setStory((current) => ({ ...current, likes: response.totalLikes }));
    } catch (requestError) {
      setError(requestError.response?.data?.message || "Unable to update like.");
    }
  };

  const firstChapterId = chapters[0]?._id || chapters[0]?.number || "chapter-1";

  if (isLoading) {
    return <main className="lumora-story-details">Loading story...</main>;
  }

  if (error && !story) {
    return <main className="lumora-story-details">{error}</main>;
  }

  return (
    <main className="lumora-story-details">
      {/* =====================================================
          BACK
      ===================================================== */}

      <div className="lumora-story-details__topbar">
        <div className="lumora-story-details__container">
          <Link
            to="/discover"
            className="lumora-story-details__back"
          >
            <FaArrowLeft size={11} />
            Back to Discover
          </Link>
        </div>
      </div>

      {/* =====================================================
          STORY HERO
      ===================================================== */}

      <section className="lumora-story-details__hero">
        <div className="lumora-story-details__container">
          <div className="lumora-story-details__hero-grid">
            <StoryCover story={story} />

            <div className="lumora-story-details__info">
              <div className="lumora-story-details__badges">
                <span className="lumora-story-details__badge lumora-story-details__badge--primary">
                  {story.category}
                </span>

                <span className="lumora-story-details__badge">
                  {story.storyType}
                </span>

                <span className="lumora-story-details__status">
                  {story.status}
                </span>
              </div>

              <h1>{story.title}</h1>

              <p className="lumora-story-details__subtitle">
                {story.subtitle}
              </p>

              <Link
                to={`/profile/${story.authorId}`}
                className="lumora-story-details__author"
              >
                <span className="lumora-story-details__author-avatar">
                  {story.author
                    .split(" ")
                    .map((name) => name[0])
                    .join("")}
                </span>

                <span>
                  <small>Written by</small>
                  <strong>{story.author}</strong>
                </span>
              </Link>

              <div className="lumora-story-details__stats">
                <span>
                  <FaEye size={12} />
                  {story.views}
                  <small>Views</small>
                </span>

                <span>
                  <FaHeart size={12} />
                  {Array.isArray(story.likes) ? story.likes.length : story.likes}
                  <small>Likes</small>
                </span>

                <span>
                  <FaBookmark size={12} />
                  {story.bookmarks}
                  <small>Bookmarks</small>
                </span>

                <span>
                  <FaStar size={12} />
                  {story.rating}
                  <small>Rating</small>
                </span>
              </div>

              <div className="lumora-story-details__actions">
                <Link
                  to={`/read/${storyId || "the-last-kingdom"}/${firstChapterId}`}
                  className="lumora-story-details__read-button"
                >
                  <FaBookOpen size={13} />
                  Read First Chapter
                  <FaArrowRight size={11} />
                </Link>

                <button
                  type="button"
                  className="lumora-story-details__bookmark-button"
                  aria-label="Bookmark story"
                  title="Bookmark story"
                  onClick={toggleBookmark}
                >
                  {isBookmarked ? <FaBookmark size={15} /> : <FaRegBookmark size={15} />}
                </button>

                <button
                  type="button"
                  className="lumora-story-details__bookmark-button"
                  aria-label="Like story"
                  title="Like story"
                  onClick={toggleLike}
                >
                  <FaHeart size={15} />
                </button>
              </div>

              <div className="lumora-story-details__updated">
                Last updated {story.updated}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          DESCRIPTION + TAGS
      ===================================================== */}

      <section className="lumora-story-details__content-section">
        <div className="lumora-story-details__container">
          <div className="lumora-story-details__content-grid">
            <div className="lumora-story-details__description">
              <span className="lumora-story-details__eyebrow">
                ABOUT THIS STORY
              </span>

              <h2>About the story</h2>

              <p>{story.description}</p>

              <div className="lumora-story-details__tags">
                {story.tags.map((tag) => (
                  <span key={tag}>{tag}</span>
                ))}
              </div>
            </div>

            <aside className="lumora-story-details__quick-info">
              <div>
                <small>STORY TYPE</small>
                <strong>{story.storyType}</strong>
              </div>

              <div>
                <small>GENRE</small>
                <strong>{story.category}</strong>
              </div>

              <div>
                <small>CHAPTERS</small>
                <strong>{story.chapters}</strong>
              </div>

              <div>
                <small>STATUS</small>
                <strong>{story.status}</strong>
              </div>
            </aside>
          </div>
        </div>
      </section>

      {/* =====================================================
          CHAPTERS
      ===================================================== */}

      <section className="lumora-story-details__chapters">
        <div className="lumora-story-details__container">
          <div className="lumora-story-details__section-header">
            <div>
              <span className="lumora-story-details__eyebrow">
                READ THE STORY
              </span>

              <h2>Chapters</h2>
            </div>

            <span className="lumora-story-details__chapter-count">
              {story.chapters} chapters
            </span>
          </div>

          <div className="lumora-story-details__chapter-list">
            {chapters.map((chapter, index) => (
              <Link
                key={chapter._id || chapter.number}
                to={`/read/${
                  storyId || "the-last-kingdom"
                }/${chapter._id || chapter.number}`}
                className="lumora-story-details__chapter"
              >
                <div className="lumora-story-details__chapter-number">
                  {String(chapter.chapterNumber || chapter.number || index + 1).padStart(2, "0")}
                </div>

                <div className="lumora-story-details__chapter-info">
                  <strong>{chapter.title}</strong>

                  <span>
                    Chapter {chapter.number} · {chapter.date}
                  </span>
                </div>

                <div className="lumora-story-details__chapter-views">
                  <FaEye size={10} />
                  {chapter.views}
                </div>

                <FaArrowRight
                  className="lumora-story-details__chapter-arrow"
                  size={11}
                />
              </Link>
            ))}
          </div>

          {story.chapters > chapters.length && (
            <button
              type="button"
              className="lumora-story-details__load-more"
            >
              Show all {story.chapters} chapters
            </button>
          )}
        </div>
      </section>

      {/* =====================================================
          AUTHOR
      ===================================================== */}

      <section className="lumora-story-details__author-section">
        <div className="lumora-story-details__container">
          <div className="lumora-story-details__author-card">
            <div className="lumora-story-details__author-large">
              {story.author
                .split(" ")
                .map((name) => name[0])
                .join("")}
            </div>

            <div className="lumora-story-details__author-card-content">
              <span className="lumora-story-details__eyebrow">
                ABOUT THE AUTHOR
              </span>

              <h2>{story.author}</h2>

              <p>
                A writer creating stories about characters, worlds,
                and moments that stay with readers.
              </p>

              <Link to={`/profile/${story.authorId}`}>
                View writer profile
                <FaArrowRight size={10} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          CTA
      ===================================================== */}

      <section className="lumora-story-details__cta">
        <div className="lumora-story-details__container">
          <div className="lumora-story-details__cta-card">
            <FaBookOpen size={17} />

            <span>READY TO READ?</span>

            <h2>Start the story.</h2>

            <p>
              Pick up where the story begins and see where it takes
              you.
            </p>

            <Link
              to={`/read/${storyId || "the-last-kingdom"}/${firstChapterId}`}
            >
              Read Chapter 1
              <FaArrowRight size={11} />
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}

export default StoryDetails;
