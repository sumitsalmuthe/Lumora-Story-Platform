import { Link, useLocation, useNavigate } from "react-router-dom";
import { BookOpen, Eye, EyeOff, ArrowRight } from "lucide-react";
import { useState } from "react";

import lumoraLogo from "../../../assets/logo/lumora-logo-bold.svg";
import useAuth from "../../../context/AuthContext/useAuth";

import "./Login.css";

function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    remember: false,
  });

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;

    setFormData((current) => ({
      ...current,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setIsSubmitting(true);

    try {
      await login({ email: formData.email, password: formData.password });
      const destination = location.state?.from?.pathname || "/";
      navigate(destination, { replace: true });
    } catch (requestError) {
      setError(requestError.response?.data?.message || "Unable to log in. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="login-page">
      <div className="login-page__decor login-page__decor--top" />
      <div className="login-page__decor login-page__decor--bottom" />

      <section className="login-container">
        {/* Brand */}
        <div className="login-brand">
          <img
  src={lumoraLogo}
  alt="Lumora"
  className="auth-logo"
/>
        </div>

        {/* Login Card */}
        <div className="login-card">
          <div className="login-card__header">
            <div className="login-icon">
              <BookOpen size={22} strokeWidth={1.8} />
            </div>

            <span className="login-eyebrow">WELCOME BACK</span>

            <h1>Welcome back.</h1>

            <p>
              Sign in to continue reading, writing, and discovering stories
              on Lumora.
            </p>
          </div>

          <form className="login-form" onSubmit={handleSubmit}>
            {error && <p className="auth-form-error" role="alert">{error}</p>}
            {/* Email */}
            <div className="login-field">
              <label htmlFor="email">Email address</label>

              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="you@example.com"
                autoComplete="email"
                required
              />
            </div>

            {/* Password */}
            <div className="login-field">
              <div className="login-field__label-row">
                <label htmlFor="password">Password</label>

                <button
                  type="button"
                  className="login-forgot"
                  onClick={() =>
                    console.log("Forgot password clicked")
                  }
                >
                  Forgot password?
                </button>
              </div>

              <div className="login-password">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  required
                />

                <button
                  type="button"
                  className="login-password__toggle"
                  onClick={() =>
                    setShowPassword((current) => !current)
                  }
                  aria-label={
                    showPassword
                      ? "Hide password"
                      : "Show password"
                  }
                >
                  {showPassword ? (
                    <EyeOff size={18} strokeWidth={1.8} />
                  ) : (
                    <Eye size={18} strokeWidth={1.8} />
                  )}
                </button>
              </div>
            </div>

            {/* Remember Me */}
            <label className="login-remember">
              <input
                type="checkbox"
                name="remember"
                checked={formData.remember}
                onChange={handleChange}
              />

              <span>Remember me</span>
            </label>

            {/* Submit */}
            <button type="submit" className="login-submit" disabled={isSubmitting}>
              <span>{isSubmitting ? "Logging in..." : "Log in"}</span>
              <ArrowRight size={18} strokeWidth={1.9} />
            </button>
          </form>

          {/* Divider */}
          <div className="login-divider">
            <span>or</span>
          </div>

          {/* Register */}
          <div className="login-register">
            <span>Don't have an account?</span>

            <Link to="/register">
              Create an account
            </Link>
          </div>
        </div>

        {/* Footer */}
        <p className="login-footer">
          By continuing, you agree to Lumora's{" "}
          <Link to="/terms">Terms</Link> and{" "}
          <Link to="/privacy">Privacy Policy</Link>.
        </p>
      </section>
    </main>
  );
}

export default Login;
