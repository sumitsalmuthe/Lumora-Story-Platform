import { Link, useNavigate } from "react-router-dom";
import {
  BookOpen,
  Eye,
  EyeOff,
  ArrowRight,
} from "lucide-react";
import { useState } from "react";

import lumoraLogo from "../../../assets/logo/lumora-logo-bold.svg";
import useAuth from "../../../context/AuthContext/useAuth";

import "./Register.css";

function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    agree: false,
  });

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;

    setFormData((current) => ({
      ...current,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setIsSubmitting(true);

    try {
      await register({
        username: formData.name,
        email: formData.email,
        password: formData.password,
      });
      navigate("/", { replace: true });
    } catch (requestError) {
      setError(requestError.response?.data?.message || "Unable to create your account. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="register-page">
      <div className="register-page__decor register-page__decor--top" />
      <div className="register-page__decor register-page__decor--bottom" />

      <section className="register-container">

        {/* Brand */}
        <div className="register-brand">
          <img
  src={lumoraLogo}
  alt="Lumora"
  className="auth-logo"
/>
        </div>

        {/* Card */}
        <div className="register-card">

          <div className="register-card__header">
            <div className="register-icon">
              <BookOpen size={22} strokeWidth={1.8} />
            </div>

            <span className="register-eyebrow">
              JOIN LUMORA
            </span>

            <h1>Create your account.</h1>

            <p>
              Join Lumora to discover stories, follow writers,
              and share worlds of your own.
            </p>
          </div>

          <form
            className="register-form"
            onSubmit={handleSubmit}
          >
            {error && <p className="auth-form-error" role="alert">{error}</p>}

            {/* Name */}
            <div className="register-field">
              <label htmlFor="name">
                Your name
              </label>

              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter your name"
                autoComplete="name"
                required
              />
            </div>

            {/* Email */}
            <div className="register-field">
              <label htmlFor="email">
                Email address
              </label>

              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="you@example.com"
                autoComplete="email"
                required
              />
            </div>

            {/* Password */}
            <div className="register-field">
              <label htmlFor="password">
                Password
              </label>

              <div className="register-password">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Create a password"
                  autoComplete="new-password"
                  required
                />

                <button
                  type="button"
                  className="register-password__toggle"
                  onClick={() =>
                    setShowPassword(
                      (current) => !current
                    )
                  }
                  aria-label={
                    showPassword
                      ? "Hide password"
                      : "Show password"
                  }
                >
                  {showPassword ? (
                    <EyeOff
                      size={18}
                      strokeWidth={1.8}
                    />
                  ) : (
                    <Eye
                      size={18}
                      strokeWidth={1.8}
                    />
                  )}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div className="register-field">
              <label htmlFor="confirmPassword">
                Confirm password
              </label>

              <div className="register-password">
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={
                    showConfirmPassword
                      ? "text"
                      : "password"
                  }
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="Repeat your password"
                  autoComplete="new-password"
                  required
                />

                <button
                  type="button"
                  className="register-password__toggle"
                  onClick={() =>
                    setShowConfirmPassword(
                      (current) => !current
                    )
                  }
                  aria-label={
                    showConfirmPassword
                      ? "Hide password"
                      : "Show password"
                  }
                >
                  {showConfirmPassword ? (
                    <EyeOff
                      size={18}
                      strokeWidth={1.8}
                    />
                  ) : (
                    <Eye
                      size={18}
                      strokeWidth={1.8}
                    />
                  )}
                </button>
              </div>
            </div>

            {/* Terms */}
            <label className="register-terms">
              <input
                type="checkbox"
                name="agree"
                checked={formData.agree}
                onChange={handleChange}
                required
              />

              <span>
                I agree to Lumora's{" "}
                <Link to="/terms">
                  Terms
                </Link>{" "}
                and{" "}
                <Link to="/privacy">
                  Privacy Policy
                </Link>
                .
              </span>
            </label>

            {/* Submit */}
            <button
              type="submit"
              className="register-submit"
              disabled={isSubmitting}
            >
              <span>{isSubmitting ? "Creating account..." : "Create account"}</span>

              <ArrowRight
                size={18}
                strokeWidth={1.9}
              />
            </button>
          </form>

          {/* Login */}
          <div className="register-login">
            <span>
              Already have an account?
            </span>

            <Link to="/login">
              Log in
            </Link>
          </div>
        </div>

        <p className="register-footer">
          Create your account and start exploring
          stories on Lumora.
        </p>

      </section>
    </main>
  );
}

export default Register;
