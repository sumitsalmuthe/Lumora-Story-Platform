import { useState } from "react";
import authService from "../../services/auth/authService";
import AuthContext from "./authContext";
const TOKEN_KEY = "lumora-token";
const USER_KEY = "lumora-user";

const getStoredUser = () => {
  try {
    const storedUser = localStorage.getItem(USER_KEY);
    return storedUser ? JSON.parse(storedUser) : null;
  } catch {
    localStorage.removeItem(USER_KEY);
    return null;
  }
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(getStoredUser);

  const persistSession = (session) => {
    localStorage.setItem(TOKEN_KEY, session.token);
    localStorage.setItem(USER_KEY, JSON.stringify(session.user));
    setUser(session.user);
  };

  const login = async (credentials) => {
    const session = await authService.login(credentials);
    persistSession(session);
    return session.user;
  };

  const register = async (account) => {
    const session = await authService.register(account);
    persistSession(session);
    return session.user;
  };

  const becomeWriter = async () => {
    const session = await authService.becomeWriter();
    persistSession(session);
    return session.user;
  };

  const logout = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    setUser(null);
  };

  const value = {
    user,
    isAuthenticated: Boolean(user),
    isWriter: user?.role === "writer" || user?.role === "admin",
    isAdmin: user?.role === "admin",
    login,
    register,
    becomeWriter,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
