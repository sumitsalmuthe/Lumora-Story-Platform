const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema(
  {
    // ======================================
    // Username
    // ======================================

    username: {
      type: String,
      required: true,
      trim: true,
      unique: true,
      lowercase: true,
    },

    // ======================================
    // Email
    // ======================================

    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },

    // ======================================
    // Google Account ID
    // ======================================

    /*
     * Google "sub" value.
     *
     * This is the stable unique identifier
     * for the Google account.
     *
     * Sparse allows existing local users
     * to have no googleId.
     */

    googleId: {
      type: String,
      unique: true,
      sparse: true,
      index: true,
    },

    // ======================================
    // Facebook Account ID
    // ======================================

    /*
     * Facebook user ID.
     *
     * This is the stable identifier used
     * to associate a Facebook account with
     * a Lumora user.
     *
     * Sparse allows existing local/Google
     * users to have no facebookId.
     */

    facebookId: {
      type: String,
      unique: true,
      sparse: true,
      index: true,
    },

    // ======================================
    // Authentication Provider
    // ======================================

    authProvider: {
      type: String,
      enum: ["local", "google", "facebook"],
      default: "local",
    },

    // ======================================
    // Password
    // ======================================

    /*
     * Password remains required so we don't
     * break the existing User model.
     *
     * Google/Facebook accounts receive a
     * secure random internal password that
     * the user never sees.
     */

    password: {
      type: String,
      required: true,
    },

    // ======================================
    // Profile
    // ======================================

    avatar: {
      type: String,
      default: "",
    },

    bio: {
      type: String,
      default: "",
      maxlength: 500,
    },

    // ======================================
    // Role
    // ======================================

    role: {
      type: String,
      enum: ["reader", "writer", "admin"],
      default: "reader",
    },

    // ======================================
    // Verification
    // ======================================

    verified: {
      type: Boolean,
      default: false,
    },

    // ======================================
    // Account Status
    // ======================================

    isActive: {
      type: Boolean,
      default: true,
    },

    // ======================================
    // Writer Profile
    // ======================================

    writerProfile: {
      penName: {
        type: String,
        default: "",
      },

      joinedAsWriter: {
        type: Date,
        default: null,
      },
    },

    // ======================================
    // Last Login
    // ======================================

    lastLogin: {
      type: Date,
      default: null,
    },
  },

  {
    timestamps: true,
  }
);

// ======================================
// Password Hash
// ======================================

userSchema.pre("save", async function () {
  /*
   * Password already hashed
   */

  if (!this.isModified("password")) {
    return;
  }

  const salt = await bcrypt.genSalt(10);

  this.password = await bcrypt.hash(this.password, salt);
});

// ======================================
// Compare Password
// ======================================

userSchema.methods.matchPassword = async function (password) {
  return await bcrypt.compare(password, this.password);
};

module.exports = mongoose.model("User", userSchema);