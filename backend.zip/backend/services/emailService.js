const nodemailer = require("nodemailer");

const SMTP_HOST =
  process.env.SMTP_HOST || "smtp.gmail.com";

const SMTP_PORT =
  Number(process.env.SMTP_PORT) || 587;

const SMTP_SECURE =
  String(process.env.SMTP_SECURE).toLowerCase() === "true";

const SMTP_USER =
  process.env.SMTP_USER;

const SMTP_PASS =
  process.env.SMTP_PASS;

const EMAIL_FROM =
  process.env.EMAIL_FROM || SMTP_USER;

const transporter = nodemailer.createTransport({
  host: SMTP_HOST,
  port: SMTP_PORT,
  secure: SMTP_SECURE,
  auth: {
    user: SMTP_USER,
    pass: SMTP_PASS,
  },
});

/*
|--------------------------------------------------------------------------
| Password Reset Email
|--------------------------------------------------------------------------
*/

const sendPasswordResetEmail = async ({
  to,
  username,
  resetUrl,
}) => {
  const displayName =
    username || "there";

  await transporter.sendMail({
    from: EMAIL_FROM,
    to,
    subject: "Reset your Lumora password",

    text: `
Hello ${displayName},

We received a request to reset your Lumora password.

Reset your password using this link:

${resetUrl}

This link will expire in 15 minutes.

If you did not request a password reset, you can safely ignore this email.

Lumora
Read • Write • Inspire
`,

    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
  />
  <title>Reset your Lumora password</title>
</head>

<body style="
  margin:0;
  padding:0;
  background:#f5f5f5;
  font-family:Arial,Helvetica,sans-serif;
">

  <div style="
    max-width:680px;
    margin:40px auto;
    padding:20px;
  ">

    <div style="
      background:#ffffff;
      border-radius:20px;
      padding:42px;
      box-shadow:0 8px 30px rgba(0,0,0,0.08);
    ">

      <div style="
        font-size:32px;
        font-weight:700;
        color:#ff6048;
        margin-bottom:32px;
      ">
        Lumora
      </div>

      <h1 style="
        margin:0 0 20px;
        font-size:28px;
        color:#111111;
      ">
        Reset your password
      </h1>

      <p style="
        font-size:16px;
        line-height:1.7;
        color:#444444;
      ">
        Hello ${displayName},
      </p>

      <p style="
        font-size:16px;
        line-height:1.7;
        color:#444444;
      ">
        We received a request to reset your Lumora password.
      </p>

      <div style="margin:32px 0;">
        <a
          href="${resetUrl}"
          style="
            display:inline-block;
            padding:15px 28px;
            background:#ff6048;
            color:#ffffff;
            text-decoration:none;
            border-radius:10px;
            font-weight:700;
            font-size:15px;
          "
        >
          Reset Password
        </a>
      </div>

      <p style="
        font-size:15px;
        line-height:1.7;
        color:#555555;
      ">
        This link will expire in
        <strong>15 minutes</strong>.
      </p>

      <p style="
        font-size:15px;
        line-height:1.7;
        color:#555555;
      ">
        If you did not request a password reset,
        you can safely ignore this email.
      </p>

      <hr style="
        border:none;
        border-top:1px solid #eeeeee;
        margin:32px 0;
      " />

      <p style="
        margin:0;
        font-size:13px;
        color:#888888;
      ">
        Lumora — Read • Write • Inspire
      </p>

    </div>

  </div>

</body>
</html>
`,
  });
};


/*
|--------------------------------------------------------------------------
| Email Verification Email
|--------------------------------------------------------------------------
*/

const sendEmailVerificationEmail = async ({
  to,
  username,
  verificationUrl,
}) => {
  const displayName =
    username || "there";

  await transporter.sendMail({
    from: EMAIL_FROM,
    to,
    subject: "Verify your Lumora email address",

    text: `
Hello ${displayName},

Welcome to Lumora!

Please verify your email address by clicking the link below:

${verificationUrl}

This verification link will expire in 15 minutes.

If you did not create a Lumora account, you can safely ignore this email.

Lumora
Read • Write • Inspire
`,

    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
  />
  <title>Verify your Lumora email</title>
</head>

<body style="
  margin:0;
  padding:0;
  background:#f5f5f5;
  font-family:Arial,Helvetica,sans-serif;
">

  <div style="
    max-width:680px;
    margin:40px auto;
    padding:20px;
  ">

    <div style="
      background:#ffffff;
      border-radius:20px;
      padding:42px;
      box-shadow:0 8px 30px rgba(0,0,0,0.08);
    ">

      <div style="
        font-size:32px;
        font-weight:700;
        color:#ff6048;
        margin-bottom:32px;
      ">
        Lumora
      </div>

      <h1 style="
        margin:0 0 20px;
        font-size:28px;
        color:#111111;
      ">
        Verify your email
      </h1>

      <p style="
        font-size:16px;
        line-height:1.7;
        color:#444444;
      ">
        Hello ${displayName},
      </p>

      <p style="
        font-size:16px;
        line-height:1.7;
        color:#444444;
      ">
        Welcome to Lumora!
        Please verify your email address to complete
        your account setup.
      </p>

      <div style="margin:32px 0;">
        <a
          href="${verificationUrl}"
          style="
            display:inline-block;
            padding:15px 28px;
            background:#ff6048;
            color:#ffffff;
            text-decoration:none;
            border-radius:10px;
            font-weight:700;
            font-size:15px;
          "
        >
          Verify Email Address
        </a>
      </div>

      <p style="
        font-size:15px;
        line-height:1.7;
        color:#555555;
      ">
        This verification link will expire in
        <strong>15 minutes</strong>.
      </p>

      <p style="
        font-size:15px;
        line-height:1.7;
        color:#555555;
      ">
        If you did not create a Lumora account,
        you can safely ignore this email.
      </p>

      <hr style="
        border:none;
        border-top:1px solid #eeeeee;
        margin:32px 0;
      " />

      <p style="
        margin:0;
        font-size:13px;
        color:#888888;
      ">
        Lumora — Read • Write • Inspire
      </p>

    </div>

  </div>

</body>
</html>
`,
  });
};


/*
|--------------------------------------------------------------------------
| Exports
|--------------------------------------------------------------------------
*/

module.exports = {
  sendPasswordResetEmail,
  sendEmailVerificationEmail,
};